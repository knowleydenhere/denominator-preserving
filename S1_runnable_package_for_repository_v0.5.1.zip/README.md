# Supplementary File S1 - pathway-accounting QA utility (v0.5.1)

This package implements the accounting rules described in the manuscript using synthetic data. It is a reproducibility and software-quality-assurance supplement, not clinical validation and not a production FHIR profile.

## Inputs

CSV mode reconciles five separate source extracts plus a configuration file:

1. `eligibility.csv`
2. `ai_log.csv`
3. `disposition.csv`
4. `outcome_evidence.csv`
5. `transitions.csv`
6. `config.json`

The audit checks source continuity, episode uniqueness, closed vocabularies, tri-state booleans, temporal ordering, prespecified branch windows, transition provenance, source-of-record rules, evidence-grade rules, and branch reconciliation. C/F/U/T states are derived from the source records rather than entered as final outcomes.

## Accounting identities

All deployments use:

- `N0 = N_attempted + N_not_attempted`
- `N_attempted = N_AI_output + N_technical_failure`
- AI-output view: `N_AI_output = sum(index AI-output branches)`

Decision-support and hybrid execution views also use:

- `N_AI_output = N_authorized_disposition + N_disposition_unascertained + N_disposition_extract_missing`
- `N_authorized_disposition = sum(index execution branches)`

`N_disposition_extract_missing` is a source-reconciliation failure. It is not treated as a clinical unascertained state.

For each index or derived branch with a protocol-required next step:

- `N_b = C_b + F_b + U_b + T_b`

Derived branches keep their own denominator and clock and are reported separately from the index-branch sum.

## Outcome rules

- **C**: completion occurs on or before the configured deadline; evidence grade A/B/C is required.
- **F**: affirmative non-completion, completion after the deadline, or no event in a prespecified validated closed source observable through the deadline.
- **T**: a prespecified truncating event occurs before the deadline.
- **U**: status cannot otherwise be established.

Contradictory evidence is rejected. Evidence grades without completion evidence are rejected. Late completion remains affirmative evidence, but it is classified as F for the fixed-window completion endpoint.

## Initiation and completion clocks

`branch_windows_days` defines the completion window after entry into an execution branch. In clinician-mediated pathways, the execution-branch clock starts at the final authorized disposition.

`disposition_windows_days` defines an initiation window from AI output to authorized disposition, keyed by the AI-output branch. It is optional, but for decision-support and hybrid pathways the audit warns when it is absent, and warns for any required-next-step AI-output branch without a window.

The report includes an **initiation identity** for clinician-mediated and hybrid pathways, overall and by AI-output branch:

- `N_AI_output = on_time + late + no_window_configured + disposition_unascertained + disposition_extract_missing`

Because the execution-view completion clock starts at the authorized disposition, a completed episode can have had a long delay before the clinician acted. Each index-branch summary therefore also reports an `initiation_adjusted` block: completed episodes split into `C_initiated_on_time`, `C_initiated_late`, and `C_initiation_not_assessed`, plus `on_time_initiation_and_completion_floor` (on-time initiation and completion by the deadline, divided by N_b). That floor is reported only when every completed episode has an assessable initiation window. A late disposition is reported as a pathway delay; it does not reset or erase the initiation assessment.

## FHIR R4 fixture

The synthetic FHIR fixture exercises selected native R4 elements and links:

- `Encounter.period.start` for eligibility date;
- `Observation.effectiveDateTime` and `Observation.valueString` for AI output;
- `ServiceRequest.authoredOn` for disposition date;
- `ServiceRequest.occurrencePeriod.end` (preferred) or `ServiceRequest.occurrenceDateTime` for the downstream deadline;
- `Task.basedOn` for linkage to the request;
- `Procedure.performedDateTime` or `Procedure.performedPeriod` for completed procedure timing;
- `Procedure.status = not-done` plus `statusReason` for affirmative procedure non-completion.

For multiple completed procedures linked to the same request, the earliest completion date is used. Any completed Procedure without a `performed[x]` date (or finished Encounter without a period) is rejected, even when another dated completion is linked to the same request. Evidence grade is never invented when it is absent.

A `not-done` Procedure dated before the earliest completion is treated as a rescheduled attempt: completion governs and a warning is issued. A `not-done` Procedure that is undated, or dated after the completion, is retained as contradictory evidence and fails the audit.

Audit-specific concepts such as branch vocabulary, evidence grade, source-of-record status, override state, and optional reference-resolution status remain extensions. The fixture tests serialization and extraction of the audit schema; it is not an implementation guide.

See `FHIR_MAPPING_NOTES.md` for details.

## Run

Valid CSV example:

```bash
python3 denominator_audit.py --input-dir examples/valid --threshold 0.50 --report output/valid_report.json
```

FHIR example:

```bash
python3 denominator_audit.py --fhir-bundle examples/fhir/synthea_augmented_ai_audit_bundle.json --config examples/fhir/config.json --extract-dir output/fhir_extract --threshold 0.50 --report output/fhir_report.json
```

Regression suite:

```bash
python3 -m unittest discover -s tests -v
```

The v0.5.1 suite contains **43 tests**. It includes the source-reconciliation and branch-transition cases from earlier versions plus R4 `Procedure.performed[x]`, `ServiceRequest.occurrencePeriod.end`, missing evidence grade, multiple completion resources, undated completion alongside a dated one, `Procedure.status=not-done` (including rescheduled and contradictory ordering), same-branch override rejection, the initiation identity, initiation-adjusted completion, missing initiation-window warnings, truncation/non-completion contradiction, and inappropriate evidence-grade probes.

## Statistical outputs

The utility reports the observed completion floor, U-based upper identification limit, Wilson interval for the observed completion proportion, Grade A/B-only floor, and tipping-point state. Wilson intervals are episode-level and assume independent episodes. Repeated patient IDs generate a warning; cluster-aware inference must be performed outside this QA utility.

## Requirements

- Python 3.10 or later
- Standard library only
- No patient data are included

## License and version

MIT License. Version 0.5.1, 2026-09-22.
