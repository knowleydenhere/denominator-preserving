# FHIR R4 fixture notes

The fixture is a narrow serialization example for the audit schema. It is not a normative profile or production implementation guide.

Native R4 elements used:

- `Encounter.period.start`: eligibility date
- `Observation.effectiveDateTime`: AI-output date
- `Observation.valueString`: AI-output state
- `ServiceRequest.authoredOn`: authorized-disposition date
- `ServiceRequest.occurrencePeriod.end` (preferred; used for F001) or `ServiceRequest.occurrenceDateTime` (used for F002): downstream deadline. `occurrence[x]` describes when the requested service should happen; the end of an occurrence period is the more natural encoding of a completion deadline.
- `Task.basedOn`: link from workflow tracking to the ServiceRequest
- `Procedure.basedOn`: link from procedure evidence to the ServiceRequest
- `Procedure.performedDateTime` or `Procedure.performedPeriod`: completed procedure timing
- `Procedure.status = not-done` and `Procedure.statusReason`: affirmative procedure non-completion

The parser uses the earliest dated completed Procedure or finished Encounter linked to a request. Any completed Procedure with no `performed[x]` date, or finished Encounter with no period, causes an audit error even if another dated completion is linked to the same request. A `not-done` Procedure dated before the earliest completion is treated as a rescheduled attempt (warning); an undated or later `not-done` Procedure is contradictory evidence (error). Missing evidence grade is not replaced with a default value.

Custom extensions are used only for audit-specific fields that are not assigned a single standard representation in this example: episode ID, audit role, branch, override flag, evidence grade, source-of-record designation, observability, truncating-event reason, and optional reference-resolution status.
