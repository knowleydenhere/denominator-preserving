import json
import subprocess
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "denominator_audit.py"


class TestAudit(unittest.TestCase):
    def run_case(self, name, expected_message=None, expect_ok=False, threshold=None):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "report.json"
            cmd = [sys.executable, str(SCRIPT), "--input-dir", str(ROOT / "examples" / "adversarial" / name), "--report", str(report)]
            if threshold is not None:
                cmd += ["--threshold", str(threshold)]
            p = subprocess.run(cmd, capture_output=True, text=True)
            with open(report, encoding="utf-8") as fh:
                data = json.load(fh)
            if expect_ok:
                self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            else:
                self.assertNotEqual(p.returncode, 0, name)
                self.assertTrue(data.get("errors"), name)
                if expected_message:
                    self.assertTrue(
                        any(expected_message in e for e in data["errors"]),
                        f"{name}: expected error containing {expected_message!r}; got {data['errors']}",
                    )
            return data

    def run_valid(self, subdir="valid", threshold=0.5):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            p = subprocess.run(
                [sys.executable, str(SCRIPT), "--input-dir", str(ROOT / "examples" / subdir), "--threshold", str(threshold), "--report", str(report)],
                capture_output=True,
                text=True,
            )
            with open(report, encoding="utf-8") as fh:
                data = json.load(fh)
            self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            return data


    def run_fhir_case(self, name, expect_ok=True, expected_message=None):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            extract = Path(td) / "extract"
            p = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--fhir-bundle",
                    str(ROOT / "examples" / "fhir" / "adversarial" / f"{name}.json"),
                    "--config",
                    str(ROOT / "examples" / "fhir" / "config.json"),
                    "--report",
                    str(report),
                    "--extract-dir",
                    str(extract),
                ],
                capture_output=True,
                text=True,
            )
            with open(report, encoding="utf-8") as fh:
                d = json.load(fh)
            if expect_ok:
                self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            else:
                self.assertNotEqual(p.returncode, 0, name)
                if expected_message:
                    self.assertTrue(any(expected_message in e for e in d.get("errors", [])), f"{name}: {d.get('errors')}")
            return d

    def test_valid(self):
        d = self.run_valid()
        self.assertEqual(d["N_disposition_unascertained"], 1)
        self.assertEqual(d["N_disposition_extract_missing"], 0)

    def test_missing_ai(self):
        self.run_case("missing_ai_row", "missing ai_log row")

    def test_invalid_boolean_specific(self):
        self.run_case("invalid_boolean", "ai_attempted must be 0, 1, or unknown")

    def test_contradictory_attempt_record(self):
        self.run_case("contradictory_record", "AI not attempted but technical/output data are present")

    def test_duplicate(self):
        self.run_case("duplicate_episode", "duplicate episode_id")

    def test_branch_typo(self):
        self.run_case("invalid_branch", "invalid branch 'action_requried'")

    def test_invalid_t(self):
        self.run_case("invalid_t_reason", "is not in the prespecified truncating-event list")

    def test_missing_grade(self):
        self.run_case("missing_evidence_grade", "requires evidence_grade A/B/C")

    def test_dropped_required_outcome(self):
        self.run_case("dropped_required_outcome", "requires exactly one outcome row; found 0")

    def test_required_marked_no_step(self):
        self.run_case("required_branch_marked_no_step", "conflicts with configured branch rule")

    def test_outcome_without_execution_branch(self):
        self.run_case("outcome_without_execution_branch", "neither the index branch nor a recorded derived transition")

    def test_missing_column(self):
        self.run_case("missing_column", "missing required columns: technical_failure")

    def test_missing_disposition_extract_is_not_clinical_unascertainment(self):
        self.run_case("missing_disposition_extract", "missing disposition extract row; missing record is not equivalent to disposition unascertained")

    def test_derived_branch_is_reported_separately(self):
        d = self.run_case("derived_branch_separate", expect_ok=True, threshold=0.5)
        idx = {x["branch"]: x for x in d["index_branch_summaries"]}
        drv = {x["branch"]: x for x in d["derived_branch_summaries"]}
        self.assertEqual(idx["action_required"]["N"], 2)
        self.assertEqual(drv["action_required"]["N"], 1)

    def test_derived_branch_requires_own_outcome(self):
        self.run_case("derived_branch_missing_outcome", "derived branch 'action_required' requires exactly one outcome row; found 0")

    def test_late_completion_is_F_not_U(self):
        d = self.run_case("late_completion", expect_ok=True, threshold=0.5)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "E003" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "F")
        self.assertEqual(e["derived_reason"], "completed_after_deadline")

    def test_completion_noncompletion_contradiction(self):
        self.run_case("completion_noncompletion_contradiction", "contradictory evidence: completion_date and affirmative_noncompletion=1")

    def test_completion_before_branch(self):
        self.run_case("completion_before_branch", "completion_date precedes branch entry")

    def test_deadline_must_match_configured_window(self):
        self.run_case("deadline_mismatch", "does not match configured deadline")

    def test_invalid_eligibility_date(self):
        self.run_case("invalid_eligibility_date", "invalid eligibility_date date")

    def test_blank_transition_episode(self):
        self.run_case("blank_transition_episode", "transitions: blank episode_id")

    def test_wrong_transition_source_branch(self):
        self.run_case("wrong_transition_from_branch", "does not match the episode's actual index/previous derived branch")

    def test_reference_status_rejected_on_execution_row(self):
        self.run_case("reference_status_on_execution", "reference_status belongs to ai_output accountability rows")

    def test_tipping_bounds(self):
        sys.path.insert(0, str(ROOT))
        import denominator_audit as da
        self.assertEqual(da.tipping(3, 1, 4, 0.2)["status"], "already_met")
        self.assertEqual(da.tipping(0, 1, 4, 0.9)["status"], "unreachable")
        self.assertIsNone(da.tipping(0, 1, 4, 0.9)["fraction_U"])

    def test_source_of_record_rule(self):
        sys.path.insert(0, str(ROOT))
        import denominator_audit as da
        cfg = {"truncating_events": ["death_before_deadline"]}
        base = {
            "episode_id": "X",
            "deadline": "2026-02-01",
            "completion_date": "",
            "evidence_grade": "",
            "affirmative_noncompletion": "0",
            "noncompletion_reason": "",
            "t_reason": "",
            "t_event_date": "",
        }
        errs = []
        r = dict(base, source_of_record="validated_closed", observable_through_deadline="1")
        state, _, _ = da.derive_outcome(r, cfg, errs, date(2026, 1, 1), date(2026, 2, 1))
        self.assertEqual(state, "F")
        self.assertFalse(errs)
        errs = []
        r = dict(base, source_of_record="open", observable_through_deadline="1")
        state, reason, _ = da.derive_outcome(r, cfg, errs, date(2026, 1, 1), date(2026, 2, 1))
        self.assertEqual(state, "U")
        self.assertEqual(reason, "open_or_incomplete_source")

    def test_autonomous_safety_override_changes_execution_branch(self):
        d = self.run_valid("autonomous_override")
        self.assertEqual(d["execution_index_branches"], {"no_immediate_action": 1})

    def test_fhir_fixture(self):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            extract = Path(td) / "extract"
            p = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--fhir-bundle",
                    str(ROOT / "examples" / "fhir" / "synthea_augmented_ai_audit_bundle.json"),
                    "--config",
                    str(ROOT / "examples" / "fhir" / "config.json"),
                    "--report",
                    str(report),
                    "--extract-dir",
                    str(extract),
                ],
                capture_output=True,
                text=True,
            )
            self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            with open(report, encoding="utf-8") as fh:
                d = json.load(fh)
            self.assertEqual(d["N0"], 3)
            self.assertEqual(d["N_technical_failure"], 1)
            e = next(x for x in d["episode_states"] if x["episode_id"] == "F001")
            self.assertEqual(e["derived_state"], "C")
            self.assertEqual(e["completion_date"], "2026-04-10")

    def test_autonomous_same_branch_override_rejected(self):
        self.run_case("autonomous_same_branch_override", "autonomous safety override must change the execution branch")

    def test_disposition_delay_reported_against_initiation_window(self):
        d = self.run_case("disposition_delay", expect_ok=True, threshold=0.5)
        self.assertEqual(d["N_disposition_late"], 1)
        a = next(x for x in d["accountability"] if x["episode_id"] == "E003")
        self.assertEqual(a["disposition_lag_days"], 30)
        self.assertEqual(a["disposition_window_days"], 14)
        self.assertFalse(a["disposition_within_window"])
        self.assertTrue(any("beyond the prespecified 14-day initiation window" in w for w in d["warnings"]))

    def test_t_and_affirmative_noncompletion_contradiction(self):
        self.run_case("t_noncompletion_contradiction", "affirmative_noncompletion=1 and truncating-event evidence are both present")

    def test_grade_without_completion_rejected(self):
        self.run_case("grade_on_noncompletion", "evidence_grade is only valid when completion evidence is present")

    def test_fhir_r4_performed_datetime_completion(self):
        d = self.run_fhir_case("r4_performed_datetime", expect_ok=True)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "C")
        self.assertEqual(e["completion_date"], "2026-04-10")

    def test_fhir_missing_procedure_grade_rejected(self):
        self.run_fhir_case("missing_procedure_grade", expect_ok=False, expected_message="requires evidence_grade A/B/C")

    def test_fhir_multiple_completed_procedures_use_earliest(self):
        d = self.run_fhir_case("two_procedures_earliest_wins", expect_ok=True)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "C")
        self.assertEqual(e["completion_date"], "2026-04-10")

    def test_fhir_not_done_is_affirmative_noncompletion(self):
        d = self.run_fhir_case("procedure_not_done", expect_ok=True)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "F")
        self.assertEqual(e["derived_reason"], "patient declined procedure")

    def test_fhir_completed_procedure_without_performed_date_fails(self):
        self.run_fhir_case("completed_procedure_missing_date", expect_ok=False, expected_message="has no performed[x] date")

    def test_initiation_identity_reported(self):
        d = self.run_case("disposition_delay", expect_ok=True, threshold=0.5)
        ini = d["initiation"]
        self.assertEqual(sum(ini["totals"].values()), d["N_AI_output"])
        self.assertEqual(ini["totals"]["late"], 1)
        self.assertEqual(ini["totals"]["disposition_unascertained"], d["N_disposition_unascertained"])

    def test_initiation_adjusted_completion(self):
        d = self.run_case("disposition_delay", expect_ok=True, threshold=0.5)
        act = next(x for x in d["index_branch_summaries"] if x["branch"] == "action_required")
        adj = act["initiation_adjusted"]
        self.assertEqual(adj["C_initiated_on_time"] + adj["C_initiated_late"] + adj["C_initiation_not_assessed"], act["C"])
        self.assertEqual(adj["C_initiated_late"], 1)
        self.assertLess(adj["on_time_initiation_and_completion_floor"], act["floor"])

    def test_missing_initiation_window_warns(self):
        d = self.run_case("no_initiation_window", expect_ok=True, threshold=0.5)
        self.assertTrue(any("No disposition_windows_days configured" in w for w in d["warnings"]))
        self.assertEqual(d["initiation"]["totals"]["late"], 0)
        self.assertGreater(d["initiation"]["totals"]["no_window_configured"], 0)

    def test_fhir_occurrence_period_end_is_deadline(self):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            p = subprocess.run([sys.executable, str(SCRIPT), "--fhir-bundle", str(ROOT / "examples" / "fhir" / "synthea_augmented_ai_audit_bundle.json"),
                                "--config", str(ROOT / "examples" / "fhir" / "config.json"), "--report", str(report), "--extract-dir", str(Path(td) / "x")],
                               capture_output=True, text=True)
            self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            d = json.load(open(report, encoding="utf-8"))
            e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
            self.assertEqual(e["resolved_deadline"], "2026-04-26")

    def test_fhir_undated_completion_flagged_even_with_dated_one(self):
        self.run_fhir_case("undated_second_completion", expect_ok=False, expected_message="has no performed[x] date")

    def test_fhir_not_done_before_completion_is_reschedule(self):
        d = self.run_fhir_case("rescheduled_after_not_done", expect_ok=True)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "C")
        self.assertTrue(any("treated as a rescheduled attempt" in w for w in d["warnings"]))

    def test_fhir_not_done_after_completion_is_contradiction(self):
        self.run_fhir_case("not_done_after_completion", expect_ok=False, expected_message="contradictory evidence: completion_date and affirmative_noncompletion=1")


if __name__ == "__main__":
    unittest.main()
