#!/usr/bin/env python3
"""Deterministic, pedagogic stress test for the worked counterexample (S1.9).

The grid values are author-specified. The grid shows where complete-case reporting and
the identification interval reach different conclusions; it is not a sample of deployments
and implies nothing about how often they disagree in practice.

For a single index branch of N referrals, each scenario fixes
  p_a : completion among referrals with an ascertained outcome (C / (C + F))
  u   : number of unascertained referrals (U)
  t   : number of truncating events, handled with the composite strategy (T)
and compares the conclusion about a service threshold q under two analyses:

  conventional : C / (C + F), i.e. U and T dropped from the denominator
  accounting   : floor C / N and upper (C + U) / N, with the tipping point from
                 denominator_audit.tipping()

Technical failures, non-attempts and overrides are upstream of the referral branch.
They change neither branch figure, so they are not varied here; they do change a
total-pathway estimand, in which indicated episodes that fail upstream are classified
by whether the target event occurred.

Closed form. Assumptions: binary endpoint (target event by a fixed prespecified deadline),
T handled as composite, C and F classifications taken as correct, and p computed over the
ascertained subset (C + F > 0) of the same denominator N. Let p = C / (C + F),
s_U = U / N and s_T = T / N. Then
  floor = p (1 - s_U - s_T)          upper = p (1 - s_T) + s_U (1 - p)
so a complete-case conclusion that q is met is established only when
  s_U + s_T <= 1 - q / p,
and the interval shows q is not met when s_U (1 - p) < q - p (1 - s_T).
closed_form_call() applies these conditions; the regression suite checks that they
reproduce every cell of the grid.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from denominator_audit import tipping  # noqa: E402

P_A = [0.40, 0.50, 0.60, 0.70, 0.80]
U_SHARES = [0.0, 0.10, 0.20, 0.30, 0.40]
T_SHARES = [0.0, 0.05]


def scenario(n, p_a, u, t, q):
    ascertained = n - u - t
    c = round(p_a * ascertained)
    f = ascertained - c
    conventional = c / (c + f) if (c + f) else None
    floor, upper = c / n, (c + u) / n
    conv_call = None if conventional is None else ("met" if conventional >= q else "not met")
    if floor >= q:
        acc_call = "met"
    elif upper < q:
        acc_call = "not met"
    else:
        acc_call = "not established"
    tp = tipping(c, u, n, q)
    return {
        "N": n, "C": c, "F": f, "U": u, "T": t,
        "p_ascertained": p_a,
        "conventional": conventional, "floor": floor, "upper": upper,
        "conventional_call": conv_call, "accounting_call": acc_call,
        "agree": conv_call == acc_call,
        "fraction_U_needed": tp["fraction_U"],
    }


def closed_form_call(c, f, u, t, q, eps=1e-12):
    """Accounting conclusion from the margin conditions in the module docstring."""
    n = c + f + u + t
    p = c / (c + f)
    s_u, s_t = u / n, t / n
    met = (s_u + s_t <= 1 - q / p + eps) if p > 0 else (q <= 0)
    if met:
        return "met"
    if s_u * (1 - p) < q - p * (1 - s_t) - eps:
        return "not met"
    return "not established"


def grid(n=200, q=0.50):
    rows = []
    for t_share in T_SHARES:
        for u_share in U_SHARES:
            for p_a in P_A:
                rows.append(scenario(n, p_a, round(u_share * n), round(t_share * n), q))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--threshold", type=float, default=0.50)
    ap.add_argument("--report", type=Path)
    a = ap.parse_args()
    rows = grid(a.n, a.threshold)
    print(f"{'T':>3} {'U':>3} {'p_a':>5} {'conv':>6} {'floor':>6} {'upper':>6}  conventional / accounting")
    for r in rows:
        print(f"{r['T']:>3} {r['U']:>3} {r['p_ascertained']:>5.2f} {r['conventional']:>6.3f} {r['floor']:>6.3f} "
              f"{r['upper']:>6.3f}  {r['conventional_call']} / {r['accounting_call']}")
    agree = sum(r["agree"] for r in rows)
    print(f"agree in {agree} of {len(rows)} scenarios")
    if a.report:
        a.report.parent.mkdir(parents=True, exist_ok=True)
        a.report.write_text(json.dumps({"threshold": a.threshold, "scenarios": rows}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
