#!/usr/bin/env python3
"""Denominator-preserving pathway accounting QA supplement (v0.5.2).

This software is a reproducible *software QA check* for the methodology paper.
It is not prospective clinical validation. It reconciles separate source extracts,
validates schema and temporal logic, derives C/F/U/T from prespecified rules,
and reports index and derived transition cohorts separately.

CSV mode inputs:
  eligibility.csv, ai_log.csv, disposition.csv, outcome_evidence.csv,
  transitions.csv, config.json, and optionally total_pathway.csv

FHIR mode accepts the documented synthetic R4 fixture. The fixture uses native
FHIR links/dates for selected workflow elements plus audit-specific extensions
for concepts that are not asserted to be a standard FHIR profile.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

VERSION = "0.5.2"
DEFAULT_FHIR_EXTENSION_BASE = "https://example.org/fhir/StructureDefinition/"
VALID_BOOL = {"0": 0, "1": 1, "": None, "unknown": None, "na": None, "n/a": None}
VALID_EVIDENCE = {"A", "B", "C"}
VALID_REFERENCE = {"positive", "negative", "unascertained", "truncating", ""}


class AuditError(Exception):
    pass


def read_csv(path: Path, required):
    if not Path(path).exists():
        raise AuditError(f"missing file: {path}")
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        fields = reader.fieldnames or []
        missing = [x for x in required if x not in fields]
        if missing:
            raise AuditError(f"{Path(path).name}: missing required columns: {', '.join(missing)}")
        return list(reader)


def tri(v, field, episode, errors):
    s = (v or "").strip().lower()
    if s not in VALID_BOOL:
        errors.append(f"{episode}: {field} must be 0, 1, or unknown; got {v!r}")
        return None
    return VALID_BOOL[s]


def iso_to_date(s):
    """Parse a complete ISO-8601 date or date-time string to a calendar date.

    Trailing content is rejected (no silent truncation). Timezone-aware date-times are
    normalised to UTC before the date is taken, so sources recorded with different UTC
    offsets are compared on one calendar. Naive date-times keep their recorded date.
    Raises ValueError on anything that is not a complete ISO-8601 value.
    """
    s = s.strip()
    if len(s) == 10:
        return date.fromisoformat(s)
    if "T" not in s and " " not in s:
        raise ValueError(f"not an ISO-8601 date or date-time: {s!r}")
    dt = datetime.fromisoformat(s[:-1] + "+00:00" if s.endswith("Z") else s)
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc)
    return dt.date()


def parse_date(v, field, episode, errors, required=False):
    s = (v or "").strip()
    if not s:
        if required:
            errors.append(f"{episode}: {field} is required but blank")
        return None
    try:
        return iso_to_date(s)
    except Exception:
        errors.append(f"{episode}: invalid {field} date {v!r}")
        return None


def require_unique(rows, name, errors):
    ids = [(r.get("episode_id") or "").strip() for r in rows]
    blanks = [i for i, x in enumerate(ids, 1) if not x]
    if blanks:
        errors.append(f"{name}: blank episode_id rows {blanks}")
    dup = [k for k, v in Counter(ids).items() if k and v > 1]
    if dup:
        errors.append(f"{name}: duplicate episode_id(s): {', '.join(sorted(dup))}")


def load_config(path):
    with open(path, encoding="utf-8") as f:
        c = json.load(f)
    required = [
        "system_type",
        "valid_ai_outputs",
        "execution_branches",
        "ai_output_to_branch",
        "truncating_events",
        "branch_next_step_required",
        "branch_windows_days",
    ]
    for k in required:
        if k not in c:
            raise AuditError(f"config.json: missing {k}")
    if c["system_type"] not in {"autonomous", "decision_support", "hybrid"}:
        raise AuditError("config.json: system_type must be autonomous, decision_support, or hybrid")
    if "truncating_event_handling" in c:
        h = c["truncating_event_handling"]
        allowed = {"composite", "while_eligible", "competing_event"}
        if not isinstance(h, dict):
            raise AuditError("config.json: truncating_event_handling must be an object keyed by truncating event")
        missing = [e for e in c["truncating_events"] if e not in h]
        if missing:
            raise AuditError(f"config.json: truncating_event_handling has no strategy for {', '.join(missing)}")
        bad = {e: v for e, v in h.items() if v not in allowed}
        if bad:
            raise AuditError(f"config.json: truncating_event_handling values must be one of {sorted(allowed)}; got {bad}")
    if "disposition_windows_days" in c:
        dw = c["disposition_windows_days"]
        if not isinstance(dw, dict):
            raise AuditError("config.json: disposition_windows_days must be an object keyed by AI-output branch")
        for b, days in dw.items():
            if days is not None and (not isinstance(days, int) or days <= 0):
                raise AuditError(f"config.json: disposition window for {b} must be a positive integer or null")
    if "total_pathway_window_days" in c or "total_pathway_indication" in c:
        w = c.get("total_pathway_window_days")
        if not isinstance(w, int) or w <= 0:
            raise AuditError("config.json: total_pathway_window_days must be a positive integer")
        if c.get("total_pathway_indication") not in {"universal", "reference_standard"}:
            raise AuditError("config.json: total_pathway_indication must be universal or reference_standard")
    for b in c["execution_branches"]:
        if b not in c["branch_next_step_required"]:
            raise AuditError(f"config.json: branch_next_step_required missing branch {b}")
        if c["branch_next_step_required"][b]:
            w = c["branch_windows_days"].get(b)
            if not isinstance(w, int) or w <= 0:
                raise AuditError(f"config.json: required branch {b} needs a positive branch_windows_days value")
    return c


def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return (None, None)
    p = k / n
    d = 1 + z * z / n
    center = (p + z * z / (2 * n)) / d
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0, center - half), min(1, center + half)


def tipping(c, u, n, q):
    if not (0 <= q <= 1):
        raise ValueError("threshold q must be in [0,1]")
    if n <= 0:
        return {"threshold": q, "needed_from_U": None, "fraction_U": None, "status": "undefined"}
    if c >= q * n - 1e-12:
        return {"threshold": q, "needed_from_U": 0, "fraction_U": 0.0, "status": "already_met"}
    if u <= 0:
        return {"threshold": q, "needed_from_U": None, "fraction_U": None, "status": "unreachable"}
    need = max(0, math.ceil(q * n - c - 1e-12))
    if need > u:
        return {"threshold": q, "needed_from_U": need, "fraction_U": None, "status": "unreachable"}
    frac = min(1.0, max(0.0, need / u))
    return {"threshold": q, "needed_from_U": need, "fraction_U": frac, "status": "reachable"}


def computed_deadline(anchor, branch, config, errors, episode):
    if not config["branch_next_step_required"].get(branch, False):
        return None
    if anchor is None:
        errors.append(f"{episode}: cannot compute deadline for {branch!r} because branch-entry date is missing")
        return None
    days = config["branch_windows_days"].get(branch)
    if not isinstance(days, int) or days <= 0:
        errors.append(f"{episode}: branch {branch!r} has no valid configured window")
        return None
    return anchor + timedelta(days=days)


def derive_outcome(r, config, errors, anchor_date, expected_deadline):
    eid = r["episode_id"].strip()
    supplied_deadline = parse_date(r.get("deadline"), "deadline", eid, errors)
    if expected_deadline is None:
        errors.append(f"{eid}: deadline could not be derived from the prespecified branch window")
    elif supplied_deadline and supplied_deadline != expected_deadline:
        errors.append(
            f"{eid}: supplied deadline {supplied_deadline.isoformat()} does not match configured deadline {expected_deadline.isoformat()}"
        )
    deadline = expected_deadline or supplied_deadline

    comp = parse_date(r.get("completion_date"), "completion_date", eid, errors)
    tdate = parse_date(r.get("t_event_date"), "t_event_date", eid, errors)
    aff = tri(r.get("affirmative_noncompletion"), "affirmative_noncompletion", eid, errors)
    obs = tri(r.get("observable_through_deadline"), "observable_through_deadline", eid, errors)
    source = (r.get("source_of_record") or "").strip().lower()
    grade = (r.get("evidence_grade") or "").strip().upper()
    treason = (r.get("t_reason") or "").strip()

    if anchor_date:
        if comp and comp < anchor_date:
            errors.append(f"{eid}: completion_date precedes branch entry")
        if tdate and tdate < anchor_date:
            errors.append(f"{eid}: t_event_date precedes branch entry")

    if comp and aff == 1:
        errors.append(f"{eid}: contradictory evidence: completion_date and affirmative_noncompletion=1 are both present")
    if comp and (treason or tdate):
        errors.append(f"{eid}: contradictory evidence: completion and truncating-event evidence are both present")
    if aff == 1 and (treason or tdate):
        errors.append(f"{eid}: contradictory evidence: affirmative_noncompletion=1 and truncating-event evidence are both present")
    if grade and not comp:
        errors.append(f"{eid}: evidence_grade is only valid when completion evidence is present")

    if comp and deadline:
        if grade not in VALID_EVIDENCE:
            errors.append(f"{eid}: episode with completion evidence requires evidence_grade A/B/C")
        if comp <= deadline:
            return "C", "", deadline
        return "F", "completed_after_deadline", deadline

    if treason or tdate:
        if treason not in set(config["truncating_events"]):
            errors.append(f"{eid}: T reason {treason!r} is not in the prespecified truncating-event list")
        if not tdate:
            errors.append(f"{eid}: T reason requires t_event_date")
        elif deadline and tdate > deadline:
            errors.append(f"{eid}: truncating event occurs after deadline")
        return "T", treason or "invalid_t_reason", deadline

    if aff == 1:
        return "F", (r.get("noncompletion_reason") or "affirmative_noncompletion").strip(), deadline

    if source == "validated_closed" and obs == 1:
        return "F", "validated_source_no_event", deadline

    if source in {"", "none", "not_designated"}:
        reason = "no_designated_source"
    elif obs != 1:
        reason = "not_observable_through_deadline"
    elif source != "validated_closed":
        reason = "open_or_incomplete_source"
    else:
        reason = "status_unresolved"
    return "U", reason, deadline


def summarize_rows(items, threshold, errors, label, handling=None):
    cnt = Counter(r["derived_state"] for r in items)
    n = len(items)
    c, f, u, t = [cnt.get(x, 0) for x in "CFUT"]
    if n != c + f + u + t:
        errors.append(f"{label}: N != C+F+U+T")
    lo, hi = wilson(c, n)
    ab = sum(
        1
        for r in items
        if r["derived_state"] == "C" and (r.get("evidence_grade") or "").strip().upper() in {"A", "B"}
    )
    return {
        "N": n,
        "C": c,
        "F": f,
        "U": u,
        "T": t,
        "floor": c / n if n else None,
        "upper": (c + u) / n if n else None,
        "wilson_low": lo,
        "wilson_high": hi,
        "AB_verified_floor": ab / n if n else None,
        "tipping": tipping(c, u, n, threshold) if threshold is not None else None,
        # F, U and T are reported by reason: late completion, documented refusal, no-show and
        # closed-source no-event answer different operational questions even though all are F.
        "F_by_reason": dict(sorted(Counter(r["derived_reason"] for r in items if r["derived_state"] == "F").items())),
        "U_by_reason": dict(sorted(Counter(r["derived_reason"] for r in items if r["derived_state"] == "U").items())),
        "T_by_reason": dict(sorted(Counter(r["derived_reason"] for r in items if r["derived_state"] == "T").items())),
        "strategy_adjusted": strategy_adjusted(items, c, u, n, threshold, handling),
    }


def strategy_adjusted(items, c, u, n, threshold, handling):
    """Identification interval after applying each truncating reason's prespecified strategy.

    composite:        T stays in the denominator as not completing: [C/N, (C+U)/N].
    while_eligible:   T leaves the denominator: [C/(N-T_we), (C+U)/(N-T_we)].
    competing_event:  for the fixed-horizon quantity at the prespecified deadline only: with every
                      episode followed to the deadline, the cumulative incidence of completion at the
                      deadline equals C/N, so the interval is the composite one. Cause-specific hazards,
                      subdistribution hazards and cumulative incidence curves over time are different
                      estimands with different estimators (for example Aalen-Johansen), outside this utility.
    Returns None when no truncating_event_handling is configured.
    """
    if not handling:
        return None
    t_reasons = [r["derived_reason"] for r in items if r["derived_state"] == "T"]
    t_we = sum(1 for x in t_reasons if handling.get(x) == "while_eligible")
    t_ce = sum(1 for x in t_reasons if handling.get(x) == "competing_event")
    n_adj = n - t_we
    out = {
        "denominator": n_adj,
        "T_composite": len(t_reasons) - t_we - t_ce,
        "T_while_eligible": t_we,
        "T_competing_event": t_ce,
        "floor": c / n_adj if n_adj else None,
        "upper": (c + u) / n_adj if n_adj else None,
        "tipping": tipping(c, u, n_adj, threshold) if (threshold is not None and n_adj) else None,
    }
    if t_ce:
        out["note"] = ("competing-event T: this fixed-horizon interval equals the cumulative incidence of completion at "
                       "the prespecified deadline when every episode is followed to the deadline; cause-specific hazards, "
                       "subdistribution hazards and cumulative incidence curves over time are different estimands that need "
                       "other estimators (for example Aalen-Johansen) outside this utility")
    return out


TOTAL_PATHWAY_COLUMNS = [
    "episode_id", "indicated", "source_of_record", "observable_through_deadline", "completion_date",
    "evidence_grade", "affirmative_noncompletion", "noncompletion_reason", "t_reason", "t_event_date",
]


def total_pathway_view(root, cfg, E, elig_date, pathway_state, threshold, errors):
    """Total-pathway estimand over all eligible episodes (optional total_pathway.csv).

    Every eligible episode is first classified as indicated or not indicated by a rule fixed before
    analysis (universal, or a reference standard independent of AI output and arm). Each indicated
    episode is then classified C/F/U/T for the target event by a deadline measured from its
    eligibility date, using the same rules as branch outcomes. Upstream pathway states (not attempted,
    technical failure, disposition branch, override) are never endpoint states: they are reported as
    a process cross-tabulation of pathway state by endpoint. Not-indicated episodes are counted and
    excluded from the estimand, so they are neither completions nor failures.
    """
    path = Path(root) / "total_pathway.csv"
    if not path.exists():
        return None
    if "total_pathway_window_days" not in cfg:
        errors.append("total_pathway.csv supplied but config.json lacks total_pathway_window_days and total_pathway_indication")
        return None
    rows = read_csv(path, TOTAL_PATHWAY_COLUMNS)
    require_unique(rows, "total_pathway", errors)
    by_eid = {(r.get("episode_id") or "").strip(): r for r in rows if (r.get("episode_id") or "").strip()}
    for extra in sorted(set(by_eid) - E):
        errors.append(f"total_pathway: {extra} absent from eligibility")
    missing = sorted(E - set(by_eid))
    for eid in missing:
        errors.append(f"{eid}: missing total_pathway row; indication and endpoint must be determined for every eligible episode")
    window = cfg["total_pathway_window_days"]
    rule = cfg["total_pathway_indication"]
    items, n_not, n_not_with_event, undetermined = [], 0, 0, 0
    for eid in sorted(set(by_eid) & E):
        r = by_eid[eid]
        ind = tri(r.get("indicated"), "indicated", eid, errors)
        if ind is None:
            undetermined += 1
            errors.append(f"{eid}: indicated must be 0 or 1; indication is determined before analysis for every eligible episode")
            continue
        if ind == 0:
            if rule == "universal":
                errors.append(f"{eid}: indicated=0 conflicts with a universal indication rule")
            n_not += 1
            if (r.get("completion_date") or "").strip():
                n_not_with_event += 1
            continue
        anchor = elig_date.get(eid)
        deadline = anchor + timedelta(days=window) if anchor else None
        state, reason, _ = derive_outcome(r, cfg, errors, anchor, deadline)
        items.append({**r, "episode_id": eid, "derived_state": state, "derived_reason": reason,
                      "pathway_state": pathway_state.get(eid, "unclassified")})
    summary = summarize_rows(items, threshold, errors, "total_pathway", cfg.get("truncating_event_handling"))
    cross = defaultdict(lambda: Counter({k: 0 for k in "CFUT"}))
    for r in items:
        cross[r["pathway_state"]][r["derived_state"]] += 1
    n_ind = len(items)
    if not missing and not undetermined and len(E) != n_ind + n_not:
        errors.append("total pathway: N0 != N_indicated + N_not_indicated")
    return {
        "identity": "N0 = N_indicated + N_not_indicated; N_indicated = C + F + U + T",
        "indication_rule": rule,
        "window_days_from_eligibility": window,
        "N_indicated": n_ind,
        "N_not_indicated": n_not,
        "N_not_indicated_with_target_event": n_not_with_event,
        **summary,
        "by_pathway_state": {k: {"N": sum(v.values()), **{x: v[x] for x in "CFUT"}} for k, v in sorted(cross.items())},
        "episode_states": [{k: r[k] for k in ["episode_id", "pathway_state", "derived_state", "derived_reason"]} for r in items],
    }


def audit_csv(root, threshold=None):
    root = Path(root)
    errors, warnings = [], []
    cfg = load_config(root / "config.json")

    elig = read_csv(root / "eligibility.csv", ["episode_id", "patient_id", "eligibility_date"])
    ai = read_csv(root / "ai_log.csv", ["episode_id", "ai_attempted", "technical_failure", "ai_output", "ai_output_date"])
    disp = read_csv(root / "disposition.csv", ["episode_id", "authorized_disposition", "override_flag", "disposition_date"])
    out = read_csv(
        root / "outcome_evidence.csv",
        [
            "episode_id",
            "view",
            "branch",
            "next_step_required",
            "deadline",
            "source_of_record",
            "observable_through_deadline",
            "completion_date",
            "evidence_grade",
            "affirmative_noncompletion",
            "noncompletion_reason",
            "t_reason",
            "t_event_date",
            "reference_status",
        ],
    )
    trans = read_csv(root / "transitions.csv", ["episode_id", "from_branch", "derived_branch", "transition_date", "derived_deadline"])

    for rows, name in [(elig, "eligibility"), (ai, "ai_log"), (disp, "disposition")]:
        require_unique(rows, name, errors)

    eids = [(r.get("episode_id") or "").strip() for r in elig]
    E = {x for x in eids if x}
    if len(E) != len(eids):
        # require_unique has already supplied details; avoid silently shrinking N0.
        pass
    n0 = len(elig)

    elig_date = {}
    patient_by_eid = {}
    for r in elig:
        eid = (r.get("episode_id") or "").strip()
        if not eid:
            continue
        patient_by_eid[eid] = (r.get("patient_id") or "").strip()
        elig_date[eid] = parse_date(r.get("eligibility_date"), "eligibility_date", eid, errors, required=True)
    repeated_patients = sorted(k for k, v in Counter(patient_by_eid.values()).items() if k and v > 1)
    if repeated_patients:
        warnings.append(
            "Repeated patient_id values detected; Wilson intervals in this QA tool treat episodes as independent and are not cluster-robust."
        )

    ai_map = {(r.get("episode_id") or "").strip(): r for r in ai if (r.get("episode_id") or "").strip()}
    disp_map = {(r.get("episode_id") or "").strip(): r for r in disp if (r.get("episode_id") or "").strip()}
    extra_ai = sorted(set(ai_map) - E)
    extra_disp = sorted(set(disp_map) - E)
    if extra_ai:
        errors.append("ai_log: episodes absent from eligibility: " + ", ".join(extra_ai))
    if extra_disp:
        errors.append("disposition: episodes absent from eligibility: " + ", ".join(extra_disp))
    for eid in sorted(E):
        if eid not in ai_map:
            errors.append(f"{eid}: missing ai_log row")

    n_attempt = n_not = n_failure = n_ai_output = unknown_attempt = 0
    output_eids = []
    ai_output_branch, ai_output_date = {}, {}

    for eid in eids:
        if not eid:
            continue
        r = ai_map.get(eid)
        if not r:
            continue
        attempted = tri(r.get("ai_attempted"), "ai_attempted", eid, errors)
        fail = tri(r.get("technical_failure"), "technical_failure", eid, errors)
        aout = (r.get("ai_output") or "").strip()
        od = parse_date(r.get("ai_output_date"), "ai_output_date", eid, errors)
        if od and elig_date.get(eid) and od < elig_date[eid]:
            errors.append(f"{eid}: ai_output_date precedes eligibility_date")
        if attempted is None:
            unknown_attempt += 1
            errors.append(f"{eid}: ai_attempted is unknown; do not coerce to not-attempted")
            continue
        if attempted == 0:
            n_not += 1
            if fail not in (0, None) or aout or od:
                errors.append(f"{eid}: AI not attempted but technical/output data are present")
            continue
        n_attempt += 1
        if fail is None:
            errors.append(f"{eid}: attempted AI requires technical_failure=0/1")
            continue
        if fail == 1:
            n_failure += 1
            if aout:
                errors.append(f"{eid}: technical failure cannot also have an AI output")
        else:
            if not aout:
                errors.append(f"{eid}: attempted non-failure requires ai_output")
            elif aout not in cfg["valid_ai_outputs"]:
                errors.append(f"{eid}: invalid ai_output {aout!r}")
            else:
                if od is None:
                    errors.append(f"{eid}: valid AI output requires ai_output_date")
                n_ai_output += 1
                output_eids.append(eid)
                ai_output_date[eid] = od
                ai_output_branch[eid] = cfg["ai_output_to_branch"].get(aout)
                if not ai_output_branch[eid]:
                    errors.append(f"{eid}: ai_output {aout!r} lacks branch mapping")

    # Build execution-view branch assignment and distinguish explicit clinical unascertainment
    # from a record that is simply missing from the disposition extract.
    n_disp = n_disp_u = n_disp_extract_missing = 0
    execution_branch, execution_anchor = {}, {}

    if cfg["system_type"] == "autonomous":
        for eid in output_eids:
            execution_branch[eid] = ai_output_branch[eid]
            execution_anchor[eid] = ai_output_date.get(eid)
            if eid in disp_map:
                r = disp_map[eid]
                ov = tri(r.get("override_flag"), "override_flag", eid, errors)
                d = (r.get("authorized_disposition") or "").strip()
                dd = parse_date(r.get("disposition_date"), "disposition_date", eid, errors)
                if ov != 1:
                    errors.append(f"{eid}: autonomous disposition row must represent an explicit safety override with override_flag=1")
                elif d not in cfg["execution_branches"]:
                    errors.append(f"{eid}: autonomous safety override has invalid authorized_disposition {d!r}")
                else:
                    if d == ai_output_branch.get(eid):
                        errors.append(f"{eid}: autonomous safety override must change the execution branch")
                    else:
                        if dd is None:
                            errors.append(f"{eid}: autonomous safety override requires disposition_date")
                        if dd and ai_output_date.get(eid) and dd < ai_output_date[eid]:
                            errors.append(f"{eid}: disposition_date precedes ai_output_date")
                        execution_branch[eid] = d
                        execution_anchor[eid] = dd
        n_disp = len(execution_branch)
    else:
        for deid in sorted(set(disp_map) - set(output_eids)):
            errors.append(f"{deid}: disposition record exists without a valid AI output")
        for eid in output_eids:
            r = disp_map.get(eid)
            if not r:
                n_disp_extract_missing += 1
                errors.append(f"{eid}: missing disposition extract row; missing record is not equivalent to disposition unascertained")
                continue
            d = (r.get("authorized_disposition") or "").strip()
            ov = tri(r.get("override_flag"), "override_flag", eid, errors)
            dd = parse_date(r.get("disposition_date"), "disposition_date", eid, errors)
            if not d or d == "unascertained":
                n_disp_u += 1
                if ov == 1:
                    errors.append(f"{eid}: override cannot be affirmed when disposition is unascertained")
                if dd:
                    warnings.append(f"{eid}: disposition_date is present although authorized_disposition is unascertained")
            elif d not in cfg["execution_branches"]:
                errors.append(f"{eid}: invalid authorized_disposition {d!r}")
            else:
                if dd is None:
                    errors.append(f"{eid}: authorized disposition requires disposition_date")
                if dd and ai_output_date.get(eid) and dd < ai_output_date[eid]:
                    errors.append(f"{eid}: disposition_date precedes ai_output_date")
                n_disp += 1
                execution_branch[eid] = d
                execution_anchor[eid] = dd
                ai_b = ai_output_branch.get(eid)
                if ov == 0 and ai_b and d != ai_b:
                    errors.append(f"{eid}: branch differs from AI-output mapping but override_flag=0")
                if ov == 1 and ai_b and d == ai_b:
                    errors.append(f"{eid}: override_flag=1 but authorized disposition does not change the mapped branch")

    ai_index_counts = Counter(ai_output_branch[e] for e in output_eids if ai_output_branch.get(e))
    exec_index_counts = Counter(execution_branch.values())
    disposition_lag = {}
    n_disposition_late = 0
    if cfg["system_type"] != "autonomous":
        if "disposition_windows_days" not in cfg:
            warnings.append(
                "No disposition_windows_days configured: delay from AI output to authorized disposition is not assessed "
                "for this clinician-mediated/hybrid pathway."
            )
        else:
            for b, req in cfg["branch_next_step_required"].items():
                if req and cfg["disposition_windows_days"].get(b) is None:
                    warnings.append(f"No initiation window configured for required-next-step AI-output branch {b!r}.")
        for eid in output_eids:
            r = disp_map.get(eid)
            if not r or eid not in execution_branch:
                continue
            dd = parse_date(r.get("disposition_date"), "disposition_date", eid, errors)
            od = ai_output_date.get(eid)
            if not dd or not od:
                continue
            lag = (dd - od).days
            ai_b = ai_output_branch.get(eid, "")
            win = cfg.get("disposition_windows_days", {}).get(ai_b)
            within = None if win is None else lag <= win
            if within is False:
                n_disposition_late += 1
                warnings.append(f"{eid}: authorized disposition occurred {lag} days after AI output, beyond the prespecified {win}-day initiation window")
            disposition_lag[eid] = {"lag_days": lag, "window_days": win, "within_window": within}
    # Initiation identity (clinician-mediated/hybrid): every valid AI output is accounted for at the
    # AI-output-to-disposition step, by AI-output branch.
    initiation = None
    if cfg["system_type"] != "autonomous":
        states = ["on_time", "late", "no_window_configured", "disposition_unascertained", "disposition_extract_missing"]
        by_ai_branch = defaultdict(lambda: Counter({k: 0 for k in states}))
        for eid in output_eids:
            ai_b = ai_output_branch.get(eid) or "unmapped"
            if eid in execution_branch:
                lagrec = disposition_lag.get(eid)
                if lagrec is None or lagrec["within_window"] is None:
                    st = "no_window_configured"
                elif lagrec["within_window"]:
                    st = "on_time"
                else:
                    st = "late"
            elif eid in disp_map:
                st = "disposition_unascertained"
            else:
                st = "disposition_extract_missing"
            by_ai_branch[ai_b][st] += 1
        totals = Counter({k: 0 for k in states})
        for c in by_ai_branch.values():
            totals.update(c)
        if sum(totals.values()) != n_ai_output:
            errors.append("initiation identity: N_AI_output != on_time + late + no_window + unascertained + extract_missing")
        initiation = {
            "identity": "N_AI_output = on_time + late + no_window_configured + disposition_unascertained + disposition_extract_missing",
            "totals": {k: totals[k] for k in states},
            "by_ai_output_branch": {b: {k: c[k] for k in states} for b, c in sorted(by_ai_branch.items())},
        }

    if unknown_attempt == 0 and n0 != n_attempt + n_not:
        errors.append("N0 != N_attempted + N_not_attempted")
    if n_attempt != n_ai_output + n_failure:
        errors.append("N_attempted != N_AI_output + N_technical_failure")
    if n_ai_output != sum(ai_index_counts.values()):
        errors.append("AI-output view: N_AI_output != sum(index AI-output branches)")
    if cfg["system_type"] != "autonomous":
        if n_ai_output != n_disp + n_disp_u + n_disp_extract_missing:
            errors.append("execution view: N_AI_output != N_authorized_disposition + N_disposition_unascertained + N_disposition_extract_missing")
        if n_disp != sum(exec_index_counts.values()):
            errors.append("execution view: N_authorized_disposition != sum(index execution branches)")

    # Validate transitions before classifying execution outcome rows.
    valid_branches = set(cfg["execution_branches"]) | set(cfg["ai_output_to_branch"].values())
    transition_keys = set()
    transition_records = []
    for r in trans:
        eid = (r.get("episode_id") or "").strip()
        if not eid:
            errors.append("transitions: blank episode_id")
            continue
        if eid not in E:
            errors.append(f"transition {eid}: absent from eligibility")
            continue
        db = (r.get("derived_branch") or "").strip()
        fb = (r.get("from_branch") or "").strip()
        if db not in valid_branches:
            errors.append(f"{eid}: invalid derived_branch {db!r}")
        if fb not in valid_branches:
            errors.append(f"{eid}: invalid from_branch {fb!r}")
        td = parse_date(r.get("transition_date"), "transition_date", eid, errors, required=True)
        supplied_dd = parse_date(r.get("derived_deadline"), "derived_deadline", eid, errors)
        expected_dd = computed_deadline(td, db, cfg, errors, eid) if cfg["branch_next_step_required"].get(db, False) else None
        if supplied_dd and expected_dd and supplied_dd != expected_dd:
            errors.append(f"{eid}: derived_deadline does not match configured window for {db!r}")
        if supplied_dd and td and supplied_dd < td:
            errors.append(f"{eid}: derived_deadline precedes transition_date")
        k = (eid, fb, db)
        if k in transition_keys:
            errors.append(f"duplicate transition {k}")
        transition_keys.add(k)
        seq_raw = (r.get("transition_seq") or "").strip()
        seq = None
        if seq_raw:
            try:
                seq = int(seq_raw)
                if seq <= 0:
                    raise ValueError
            except ValueError:
                errors.append(f"{eid}: transition_seq must be a positive integer; got {seq_raw!r}")
                seq = None
        transition_records.append(
            {**r, "episode_id": eid, "from_branch": fb, "derived_branch": db, "_transition_date": td,
             "_derived_deadline": expected_dd, "_seq": seq, "_seq_supplied": bool(seq_raw)}
        )

    # Source-branch check for transitions: from_branch must be the actual index branch or an earlier derived branch.
    transitions_by_eid = defaultdict(list)
    for tr in transition_records:
        transitions_by_eid[tr["episode_id"]].append(tr)
    # Ordering never depends on branch names. If transition_seq is supplied (all-or-none per
    # episode) it defines the order and must agree with transition dates. Without it, transitions
    # are ordered by date, and same-day transitions are resolved by the branch chain itself
    # (a transition is admissible once its from_branch has been entered), which is independent of
    # file order and of branch spelling.
    def _mismatch(eid, fb):
        return f"{eid}: transition from_branch {fb!r} does not match the episode's actual index/previous derived branch"

    for eid in sorted(transitions_by_eid):
        trs = transitions_by_eid[eid]
        available = {execution_branch[eid]} if eid in execution_branch else set()
        supplied = [tr["_seq_supplied"] for tr in trs]
        if any(supplied) and not all(supplied):
            errors.append(f"{eid}: transition_seq must be supplied for all or none of an episode's transitions")
            continue
        if all(supplied):
            seqs = [tr["_seq"] for tr in trs]
            if None in seqs:
                continue  # invalid value already reported
            dup_seq = sorted(k for k, v in Counter(seqs).items() if v > 1)
            if dup_seq:
                errors.append(f"{eid}: duplicate transition_seq value(s) {dup_seq}")
                continue
            ordered = sorted(trs, key=lambda x: x["_seq"])
            last = None
            for tr in ordered:
                td = tr["_transition_date"]
                if td and last and td < last:
                    errors.append(f"{eid}: transition_seq order contradicts transition_date (seq {tr['_seq']} is dated {td.isoformat()}, before {last.isoformat()})")
                last = td or last
                if tr["from_branch"] not in available:
                    errors.append(_mismatch(eid, tr["from_branch"]))
                available.add(tr["derived_branch"])
            continue
        by_date = defaultdict(list)
        for tr in trs:
            by_date[tr["_transition_date"]].append(tr)  # undated rows already raised an error
        for td in sorted(d for d in by_date if d is not None):
            pending = list(by_date[td])
            if len(pending) > 1:
                warnings.append(
                    f"{eid}: {len(pending)} transitions share transition_date {td.isoformat()}; order resolved from the branch chain. "
                    "Supply transition_seq to make the order explicit."
                )
            progressed = True
            while pending and progressed:
                progressed = False
                for tr in list(pending):
                    if tr["from_branch"] in available:
                        available.add(tr["derived_branch"])
                        pending.remove(tr)
                        progressed = True
            for tr in pending:
                errors.append(_mismatch(eid, tr["from_branch"]))

    # Outcome rows: classify index and derived cohorts separately.
    outcome_seen = set()
    processed = []
    derived_lookup = defaultdict(list)
    for tr in transition_records:
        derived_lookup[(tr["episode_id"], tr["derived_branch"])].append(tr)

    for r in out:
        eid = (r.get("episode_id") or "").strip()
        view = (r.get("view") or "").strip()
        branch = (r.get("branch") or "").strip()
        if not eid:
            errors.append("outcome_evidence: blank episode_id")
            continue
        if eid not in E:
            errors.append(f"outcome_evidence: {eid} absent from eligibility")
            continue
        key = (eid, view, branch, (r.get("deadline") or "").strip())
        if key in outcome_seen:
            errors.append(f"duplicate outcome row for {key}")
        outcome_seen.add(key)
        if view not in {"execution", "ai_output"}:
            errors.append(f"{eid}: view must be execution or ai_output")
        if branch not in valid_branches:
            errors.append(f"{eid}: invalid branch {branch!r}")
        ref = (r.get("reference_status") or "").strip().lower()
        if ref not in VALID_REFERENCE:
            errors.append(f"{eid}: invalid reference_status {ref!r}")

        if view == "ai_output":
            if eid in ai_output_branch and branch != ai_output_branch[eid]:
                errors.append(f"{eid}: ai_output accountability branch {branch!r} != mapped AI branch {ai_output_branch[eid]!r}")
            processed.append({**r, "derived_state": "", "derived_reason": "", "cohort_kind": "accountability", "reference_status": ref})
            continue

        if ref:
            errors.append(f"{eid}: reference_status belongs to ai_output accountability rows, not execution rows")

        req = tri(r.get("next_step_required"), "next_step_required", eid, errors)
        expected_req = 1 if cfg["branch_next_step_required"].get(branch, False) else 0
        if req != expected_req:
            errors.append(f"{eid}: next_step_required={r.get('next_step_required')!r} conflicts with configured branch rule for {branch!r}")
        if expected_req != 1:
            errors.append(f"{eid}: execution care-completion rows are only defined for branches with a protocol-required next step")
            continue

        idx = execution_branch.get(eid)
        derived_candidates = derived_lookup.get((eid, branch), [])
        if branch == idx and derived_candidates:
            errors.append(f"{eid}: branch {branch!r} is both index and derived; cohort assignment is ambiguous")
            cohort_kind = "index"
            anchor = execution_anchor.get(eid)
        elif branch == idx:
            cohort_kind = "index"
            anchor = execution_anchor.get(eid)
        elif len(derived_candidates) == 1:
            cohort_kind = "derived"
            anchor = derived_candidates[0]["_transition_date"]
        elif len(derived_candidates) > 1:
            errors.append(f"{eid}: multiple derived transitions open branch {branch!r}; add a transition identifier")
            cohort_kind = "derived"
            anchor = derived_candidates[0]["_transition_date"]
        else:
            errors.append(f"{eid}: execution outcome branch {branch!r} is neither the index branch nor a recorded derived transition")
            cohort_kind = "unmatched"
            anchor = None

        expected_deadline = computed_deadline(anchor, branch, cfg, errors, eid)
        state, reason, deadline = derive_outcome(r, cfg, errors, anchor, expected_deadline)
        processed.append(
            {
                **r,
                "derived_state": state,
                "derived_reason": reason,
                "cohort_kind": cohort_kind,
                "resolved_deadline": deadline.isoformat() if deadline else "",
                "reference_status": ref,
            }
        )

    exec_rows = [r for r in processed if r.get("view") == "execution"]
    index_rows = defaultdict(list)
    derived_rows = defaultdict(list)
    for r in exec_rows:
        if r.get("cohort_kind") == "index":
            index_rows[(r["episode_id"], r["branch"])].append(r)
        elif r.get("cohort_kind") == "derived":
            derived_rows[(r["episode_id"], r["branch"])].append(r)

    # Exactly one outcome row for every index branch with a required next step.
    for eid, branch in execution_branch.items():
        required = bool(cfg["branch_next_step_required"].get(branch, False))
        rows = index_rows.get((eid, branch), [])
        if required and len(rows) != 1:
            errors.append(f"{eid}: index execution branch {branch!r} requires exactly one outcome row; found {len(rows)}")
        if not required and rows:
            errors.append(f"{eid}: no-immediate-action index branch should not have a care-completion outcome row unless a separate safety endpoint is prespecified")

    # Every derived branch with a required next step must also reconcile separately.
    for tr in transition_records:
        eid, db = tr["episode_id"], tr["derived_branch"]
        required = bool(cfg["branch_next_step_required"].get(db, False))
        rows = derived_rows.get((eid, db), [])
        if required and len(rows) != 1:
            errors.append(f"{eid}: derived branch {db!r} requires exactly one outcome row; found {len(rows)}")
        if not required and rows:
            errors.append(f"{eid}: derived branch {db!r} has no required next step but has an execution outcome row")

    # A transition out of a required-next-step branch must follow documented completion of that source transition.
    completion_by_eid_branch = {}
    for r in exec_rows:
        if r.get("derived_state") == "C":
            completion_by_eid_branch[(r["episode_id"], r["branch"])]=parse_date(r.get("completion_date"), "completion_date", r["episode_id"], errors)
    for tr in transition_records:
        if cfg["branch_next_step_required"].get(tr["from_branch"], False):
            cdate = completion_by_eid_branch.get((tr["episode_id"], tr["from_branch"]))
            if not cdate:
                errors.append(f"{tr['episode_id']}: transition from {tr['from_branch']!r} requires completed source branch")
            elif tr["_transition_date"] and tr["_transition_date"] < cdate:
                errors.append(f"{tr['episode_id']}: transition_date precedes completion of source branch")

    # Summaries: index and derived branch cohorts are kept separate by design.
    index_by_branch = defaultdict(list)
    derived_by_branch = defaultdict(list)
    for r in exec_rows:
        if r.get("cohort_kind") == "index":
            index_by_branch[r["branch"]].append(r)
        elif r.get("cohort_kind") == "derived":
            derived_by_branch[r["branch"]].append(r)

    index_summaries, derived_summaries = [], []
    for branch, items in sorted(index_by_branch.items()):
        s = summarize_rows(items, threshold, errors, f"index:{branch}", cfg.get("truncating_event_handling"))
        if cfg["system_type"] != "autonomous":
            c_on = c_late = c_na = 0
            for r in items:
                if r["derived_state"] != "C":
                    continue
                w = disposition_lag.get(r["episode_id"], {}).get("within_window")
                if w is True:
                    c_on += 1
                elif w is False:
                    c_late += 1
                else:
                    c_na += 1
            n = s["N"]
            s["initiation_adjusted"] = {
                "description": "Completed episodes split by whether the authorized disposition met the AI-output-to-disposition initiation window.",
                "C_initiated_on_time": c_on,
                "C_initiated_late": c_late,
                "C_initiation_not_assessed": c_na,
                "on_time_initiation_and_completion_floor": (c_on / n) if (n and c_na == 0) else None,
            }
        index_summaries.append({"cohort_kind": "index", "branch": branch, **s})
    for branch, items in sorted(derived_by_branch.items()):
        s = summarize_rows(items, threshold, errors, f"derived:{branch}", cfg.get("truncating_event_handling"))
        derived_summaries.append({"cohort_kind": "derived", "branch": branch, **s})

    # Accountability view: output branch x execution branch, plus optional reference-resolution status.
    ai_ref_by_eid = {}
    for r in processed:
        if r.get("view") == "ai_output" and r.get("reference_status"):
            ai_ref_by_eid[r["episode_id"]] = r["reference_status"]
    accountability = []
    if cfg["system_type"] != "autonomous":
        for eid in output_eids:
            if eid in execution_branch:
                d = execution_branch[eid]
                status = "available"
            elif eid in disp_map and (disp_map[eid].get("authorized_disposition") or "").strip() in {"", "unascertained"}:
                d = "unascertained"
                status = "explicit_unascertained"
            else:
                d = "extract_missing"
                status = "extract_missing"
            accountability.append(
                {
                    "episode_id": eid,
                    "ai_branch": ai_output_branch.get(eid, ""),
                    "execution_branch": d,
                    "disposition_record_status": status,
                    "overridden": d not in {"unascertained", "extract_missing", ai_output_branch.get(eid, "")},
                    "reference_status": ai_ref_by_eid.get(eid, ""),
                    "disposition_lag_days": disposition_lag.get(eid, {}).get("lag_days"),
                    "disposition_window_days": disposition_lag.get(eid, {}).get("window_days"),
                    "disposition_within_window": disposition_lag.get(eid, {}).get("within_window"),
                }
            )
    episodes_per_patient = Counter(v for v in patient_by_eid.values() if v)
    clustering = {
        "N_patients": len(episodes_per_patient),
        "N_episodes_with_patient_id": sum(episodes_per_patient.values()),
        "max_episodes_per_patient": max(episodes_per_patient.values()) if episodes_per_patient else 0,
        "wilson_intervals_cluster_robust": False,
        "note": "Wilson intervals are episode-level. When patients contribute more than one episode they understate "
                "uncertainty; use a patient-level cluster method for inference.",
    }

    reference_counts = Counter(x["reference_status"] for x in accountability if x.get("reference_status"))

    # Pathway state of every eligible episode, for the total-pathway process cross-tabulation.
    pathway_state = {}
    quiet = []
    for eid in sorted(E):
        r = ai_map.get(eid)
        if r is None:
            pathway_state[eid] = "ai_log_missing"
            continue
        att = tri(r.get("ai_attempted"), "ai_attempted", eid, quiet)
        fail = tri(r.get("technical_failure"), "technical_failure", eid, quiet)
        if att is None:
            pathway_state[eid] = "ai_attempt_unknown"
        elif att == 0:
            pathway_state[eid] = "not_attempted"
        elif fail == 1:
            pathway_state[eid] = "technical_failure"
        elif eid in execution_branch:
            ov = eid in disp_map and tri(disp_map[eid].get("override_flag"), "override_flag", eid, quiet) == 1
            pathway_state[eid] = execution_branch[eid] + ("_after_override" if ov else "")
        elif eid in output_eids and eid in disp_map:
            pathway_state[eid] = "disposition_unascertained"
        elif eid in output_eids:
            pathway_state[eid] = "disposition_extract_missing"
        else:
            pathway_state[eid] = "no_valid_output"
    total_pathway = total_pathway_view(root, cfg, E, elig_date, pathway_state, threshold, errors)

    report = {
        "version": VERSION,
        "N0": n0,
        "N_attempted": n_attempt,
        "N_not_attempted": n_not,
        "N_AI_output": n_ai_output,
        "N_technical_failure": n_failure,
        "N_authorized_disposition": n_disp,
        "N_disposition_unascertained": n_disp_u,
        "N_disposition_extract_missing": n_disp_extract_missing,
        "N_disposition_late": n_disposition_late,
        "clustering": clustering,
        "truncating_event_handling": cfg.get("truncating_event_handling"),
        "initiation": initiation,
        "ai_output_index_branches": dict(ai_index_counts),
        "execution_index_branches": dict(exec_index_counts),
        "index_branch_summaries": index_summaries,
        "derived_branch_summaries": derived_summaries,
        "total_pathway": total_pathway,
        "episode_states": [
            {k: r.get(k, "") for k in ["episode_id","view","branch","cohort_kind","derived_state","derived_reason","resolved_deadline","completion_date","evidence_grade"]}
            for r in processed
        ],
        # branch_summaries retained as a non-pooled list for backward-readable output.
        "branch_summaries": index_summaries + derived_summaries,
        "transitions": len(transition_keys),
        "accountability": accountability,
        "reference_status_counts": dict(reference_counts),
        "errors": errors,
        "warnings": warnings,
    }
    return report


def fhir_to_csv(bundle_path, outdir, issues=None, fhir_config=None):
    """Extract the documented synthetic FHIR serialization fixture into the CSV audit model.

    This is intentionally not a general FHIR implementation. The fixture uses native
    resource links/dates for selected workflow elements (ServiceRequest occurrence,
    Task basedOn, Procedure performed[x] completion evidence) and custom extensions for the
    audit-specific vocabulary.
    """
    with open(bundle_path, encoding="utf-8") as fh:
        bundle = json.load(fh)
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    entries = [e.get("resource", {}) for e in bundle.get("entry", [])]

    fhir_config = fhir_config or {}
    ext_base = fhir_config.get("fhir_extension_base", DEFAULT_FHIR_EXTENSION_BASE)
    ext_overrides = fhir_config.get("fhir_extension_urls", {}) or {}

    def url_for(name):
        """Extension URL for an audit concept: per-concept override, else base + name."""
        return ext_overrides.get(name, ext_base + name)

    def norm(v):
        """Normalise a FHIR date/dateTime to YYYY-MM-DD (UTC for offset-bearing values).
        Unparseable values are passed through unchanged so the audit reports them."""
        v = str(v or "").strip()
        if not v:
            return ""
        try:
            return iso_to_date(v).isoformat()
        except Exception:
            return v

    def ext(res, url):
        for x in res.get("extension", []):
            if x.get("url") == url:
                for key in ["valueString", "valueBoolean", "valueDateTime", "valueDate"]:
                    if key in x:
                        return x[key]
        return ""

    by_id = {f"{r.get('resourceType')}/{r.get('id')}": r for r in entries if r.get("resourceType") and r.get("id")}

    # Native completion/non-completion evidence keyed to the ServiceRequest it fulfils.
    if issues is None:
        issues = {"errors": [], "warnings": []}
    completion_by_request = {}
    grade_by_request = {}
    noncompletion_by_request = {}  # ref -> list of (date or "", reason)

    def fhir_event_date(resource):
        """Return an R4 event date for a Procedure or Encounter, or a sentinel for missing dates."""
        typ = resource.get("resourceType")
        if typ == "Procedure":
            if resource.get("performedDateTime"):
                return norm(resource["performedDateTime"])
            pp = resource.get("performedPeriod") or {}
            if pp.get("end"):
                return norm(pp["end"])
            if pp.get("start"):
                return norm(pp["start"])
            return ""
        if typ == "Encounter":
            period = resource.get("period") or {}
            return norm(period.get("end") or period.get("start") or "")
        return ""

    def status_reason_text(resource):
        reason = resource.get("statusReason") or {}
        if isinstance(reason, dict):
            if reason.get("text"):
                return str(reason["text"])
            codings = reason.get("coding") or []
            if codings:
                c = codings[0]
                return str(c.get("display") or c.get("code") or "procedure_not_done")
        return "procedure_not_done"

    for r in entries:
        if r.get("resourceType") not in {"Procedure", "Encounter"}:
            continue
        refs = [x.get("reference", "") for x in r.get("basedOn", []) if x.get("reference")]
        if not refs:
            continue
        status = r.get("status")
        if r.get("resourceType") == "Procedure" and status == "not-done":
            reason = status_reason_text(r)
            nd_date = fhir_event_date(r)
            for ref in refs:
                noncompletion_by_request.setdefault(ref, []).append((nd_date, reason))
            continue
        if status not in {"completed", "finished"}:
            continue
        when = fhir_event_date(r)
        if not when:
            date_field = "performed[x]" if r.get("resourceType") == "Procedure" else "period"
            issues["errors"].append(
                f"FHIR: completed {r.get('resourceType')}/{r.get('id')} linked to {', '.join(refs)} has no {date_field} date"
            )
            continue
        for ref in refs:
            previous = completion_by_request.get(ref)
            if not previous or when < previous:
                completion_by_request[ref] = when
                grade = ext(r, url_for("evidence-grade"))
                if grade:
                    grade_by_request[ref] = grade
                elif ref in grade_by_request:
                    del grade_by_request[ref]

    elig, ai, disp, out, trans = [], [], [], [], []
    for r in entries:
        typ = r.get("resourceType")
        eid = ext(r, url_for("episode-id"))
        role = ext(r, url_for("audit-role"))
        if typ == "Encounter" and eid and role == "eligibility":
            elig.append(
                {
                    "episode_id": eid,
                    "patient_id": r.get("subject", {}).get("reference", "").split("/")[-1],
                    "eligibility_date": norm(r.get("period", {}).get("start")),
                }
            )
        elif typ == "Observation" and eid and role == "ai-output":
            ai.append(
                {
                    "episode_id": eid,
                    "ai_attempted": ext(r, url_for("ai-attempted")),
                    "technical_failure": ext(r, url_for("technical-failure")),
                    "ai_output": r.get("valueString", ""),
                    "ai_output_date": norm(r.get("effectiveDateTime")),
                }
            )
        elif typ == "ServiceRequest" and eid and role == "disposition":
            disp.append(
                {
                    "episode_id": eid,
                    "authorized_disposition": ext(r, url_for("authorized-disposition")),
                    "override_flag": ext(r, url_for("override-flag")),
                    "disposition_date": norm(r.get("authoredOn")),
                }
            )
        elif typ == "Task" and eid and role == "outcome":
            based = ""
            if r.get("basedOn"):
                based = r["basedOn"][0].get("reference", "")
            linked_sr = by_id.get(based, {})
            deadline = ""
            occ = (linked_sr.get("occurrencePeriod") or {}).get("end") or linked_sr.get("occurrenceDateTime") or ""
            if occ:
                deadline = norm(occ)
            else:
                deadline = ext(r, url_for("deadline"))
            completion_date = completion_by_request.get(based, "")
            evidence_grade = grade_by_request.get(based, "")
            aff = ext(r, url_for("affirmative-noncompletion"))
            noncompletion_reason = ext(r, url_for("noncompletion-reason"))
            if based in noncompletion_by_request:
                nd_list = noncompletion_by_request[based]
                if completion_date:
                    # Order not-done attempts against the earliest completion. A dated not-done attempt before
                    # completion is a rescheduled attempt; an undated or later not-done remains contradictory.
                    if all(d and d <= completion_date for d, _ in nd_list):
                        issues["warnings"].append(
                            f"FHIR: {eid}: not-done Procedure precedes completed Procedure for {based}; treated as a rescheduled attempt"
                        )
                    else:
                        aff = "1"
                        noncompletion_reason = nd_list[0][1]
                else:
                    aff = "1"
                    noncompletion_reason = nd_list[0][1]
            # A cancelled/failed/rejected Task is affirmative workflow non-completion in this fixture profile.
            if not aff and r.get("status") in {"cancelled", "failed", "rejected"}:
                aff = "1"
                noncompletion_reason = noncompletion_reason or f"task_{r.get('status')}"
            out.append(
                {
                    "episode_id": eid,
                    "view": ext(r, url_for("view")),
                    "branch": ext(r, url_for("branch")),
                    "next_step_required": ext(r, url_for("next-step-required")),
                    "deadline": deadline,
                    "source_of_record": ext(r, url_for("source-of-record")),
                    "observable_through_deadline": ext(r, url_for("observable-through-deadline")),
                    "completion_date": completion_date,
                    "evidence_grade": evidence_grade,
                    "affirmative_noncompletion": aff,
                    "noncompletion_reason": noncompletion_reason,
                    "t_reason": ext(r, url_for("t-reason")),
                    "t_event_date": ext(r, url_for("t-event-date")),
                    "reference_status": ext(r, url_for("reference-status")),
                }
            )
        elif typ == "Observation" and eid and role == "transition":
            trans.append(
                {
                    "episode_id": eid,
                    "from_branch": ext(r, url_for("from-branch")),
                    "derived_branch": ext(r, url_for("derived-branch")),
                    "transition_date": norm(r.get("effectiveDateTime")),
                        "transition_seq": ext(r, url_for("transition-seq")),
                    "derived_deadline": ext(r, url_for("derived-deadline")),
                }
            )

    if entries and not elig:
        issues["errors"].append(
            "FHIR: no eligibility Encounters were recognised; check fhir_extension_base / fhir_extension_urls "
            f"(expected episode-id extension at {url_for('episode-id')!r})"
        )

    data = {
        "eligibility.csv": elig,
        "ai_log.csv": ai,
        "disposition.csv": disp,
        "outcome_evidence.csv": out,
        "transitions.csv": trans,
    }
    fields = {
        "eligibility.csv": ["episode_id", "patient_id", "eligibility_date"],
        "ai_log.csv": ["episode_id", "ai_attempted", "technical_failure", "ai_output", "ai_output_date"],
        "disposition.csv": ["episode_id", "authorized_disposition", "override_flag", "disposition_date"],
        "outcome_evidence.csv": [
            "episode_id",
            "view",
            "branch",
            "next_step_required",
            "deadline",
            "source_of_record",
            "observable_through_deadline",
            "completion_date",
            "evidence_grade",
            "affirmative_noncompletion",
            "noncompletion_reason",
            "t_reason",
            "t_event_date",
            "reference_status",
        ],
        "transitions.csv": ["episode_id", "from_branch", "derived_branch", "transition_date", "derived_deadline", "transition_seq"],
    }
    for fn, rows in data.items():
        with open(outdir / fn, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields[fn])
            writer.writeheader()
            writer.writerows(rows)
    return outdir


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input-dir", type=Path)
    p.add_argument("--fhir-bundle", type=Path)
    p.add_argument("--config", type=Path, help="config for FHIR mode")
    p.add_argument("--threshold", type=float, default=None)
    p.add_argument("--report", type=Path, default=Path("audit_report.json"))
    p.add_argument("--extract-dir", type=Path, default=Path("fhir_extract"))
    a = p.parse_args()
    if a.threshold is not None and not (0 <= a.threshold <= 1):
        p.error("--threshold must be 0..1")
    try:
        if a.fhir_bundle:
            if not a.config:
                p.error("--config is required with --fhir-bundle")
            fhir_issues = {"errors": [], "warnings": []}
            with open(a.config, encoding="utf-8") as fh:
                fhir_cfg = json.load(fh)
            d = fhir_to_csv(a.fhir_bundle, a.extract_dir, fhir_issues, fhir_cfg)
            shutil.copy2(a.config, d / "config.json")
            report = audit_csv(d, a.threshold)
            report["errors"] = fhir_issues["errors"] + report.get("errors", [])
            report["warnings"] = fhir_issues["warnings"] + report.get("warnings", [])
        elif a.input_dir:
            report = audit_csv(a.input_dir, a.threshold)
        else:
            p.error("provide --input-dir or --fhir-bundle")
    except AuditError as e:
        report = {"version": VERSION, "errors": [str(e)], "warnings": []}
    a.report.parent.mkdir(parents=True, exist_ok=True)
    with open(a.report, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    if report.get("errors"):
        print("AUDIT FLAGS")
        for e in report["errors"]:
            print("-", e)
        raise SystemExit(2)
    print("AUDIT PASS")
    keys = [
        "N0",
        "N_attempted",
        "N_not_attempted",
        "N_AI_output",
        "N_technical_failure",
        "N_authorized_disposition",
        "N_disposition_unascertained",
        "N_disposition_extract_missing",
    ]
    print(json.dumps({k: report.get(k) for k in keys}, indent=2))
    for s in report.get("index_branch_summaries", []):
        print("INDEX", s)
    for s in report.get("derived_branch_summaries", []):
        print("DERIVED", s)
    if report.get("total_pathway"):
        tp = report["total_pathway"]
        print("TOTAL_PATHWAY", {k: tp[k] for k in ["N_indicated", "N_not_indicated", "C", "F", "U", "T", "floor", "upper"]})


if __name__ == "__main__":
    main()
