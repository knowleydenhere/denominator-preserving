# Supplement 1 - pathway-accounting reference implementation (v0.5.2)

This package implements the accounting rules described in the manuscript using synthetic data. It is a reproducibility and software-quality-assurance supplement, not clinical validation and not a production FHIR profile.

## Inputs

CSV mode reconciles five separate source extracts plus a configuration file:

1. `eligibility.csv`
2. `ai_log.csv`
3. `disposition.csv`
4. `outcome_evidence.csv`
5. `transitions.csv`
6. `config.json`

The audit checks source continuity, episode uniqueness, closed vocabularies, tri-state booleans, temporal ordering, prespecified branch windows, transition provenance, source-of-record rules, evidence-grade rules, and branch reconciliation. C/F/U/T states are derived from the source records rather than entered as final outcomes.

### Dates and ordering

All dates must be complete ISO-8601 values: `YYYY-MM-DD`, or a date-time such as `2026-01-02T10:00:00Z`. Trailing content is rejected rather than truncated. Date-times with a UTC offset are converted to UTC before the calendar date is taken; naive date-times keep their recorded date. Sites should record every source consistently (all local dates, or all offset-bearing date-times), because mixing date-only local values with UTC-normalised date-times can shift an event by one day near midnight. `eligibility_date` and `transition_date` are mandatory.

The method operates at day resolution. It is intended for pathways whose completion windows are measured in days or weeks (for example screening follow-up, referral completion, or treatment initiation), not for hour-scale acute pathways.

`transitions.csv` accepts an optional `transition_seq` column (positive integer, unique within an episode, and supplied for all or none of an episode's transitions). When present it defines the order of an episode's transitions and must agree with `transition_date`. When absent, transitions are ordered by date and same-day transitions are resolved from the branch chain; a warning recommends supplying `transition_seq`. Ordering never depends on branch names or file row order, and reports are byte-identical across runs.

## Accounting identities

All deployments use:

- `N0 = N_attempted + N_not_attempted`
- `N_attempted = N_AI_output + N_technical_failure`
- AI-output view: `N_AI_output = sum(index AI-output branches)`

Decision-support and hybrid execution views also use:

- `N_AI_output = N_authorized_disposition + N_disposition_unascertained + N_disposition_extract_missing`
- `N_authorized_disposition = sum(index execution branches)`

`N_disposition_extract_missing` is a source-reconciliation failure. It is not treated as a clinical unascertained state.

For each index or derived branch with a protocol-required next step:

- `N_b = C_b + F_b + U_b + T_b`

Derived branches keep their own denominator and clock and are reported separately from the index-branch sum.

## Outcome rules

- **C**: completion occurs on or before the configured deadline; evidence grade A/B/C is required.
- **F**: affirmative non-completion, completion after the deadline, or no event in a prespecified validated closed source observable through the deadline.
- **T**: a prespecified truncating event occurs before the deadline.
- **U**: status cannot otherwise be established.

Contradictory evidence is rejected. Evidence grades without completion evidence are rejected. Late completion remains affirmative evidence, but it is classified as F for the fixed-window completion endpoint.

## Initiation and completion clocks

`branch_windows_days` defines the completion window after entry into an execution branch. In clinician-mediated pathways, the execution-branch clock starts at the final authorized disposition.

`disposition_windows_days` defines an initiation window from AI output to authorized disposition, keyed by the AI-output branch. It is optional, but for decision-support and hybrid pathways the audit warns when it is absent, and warns for any required-next-step AI-output branch without a window.

The report includes an **initiation identity** for clinician-mediated and hybrid pathways, overall and by AI-output branch:

- `N_AI_output = on_time + late + no_window_configured + disposition_unascertained + disposition_extract_missing`

Because the execution-view completion clock starts at the authorized disposition, a completed episode can have had a long delay before the clinician acted. Each index-branch summary therefore also reports an `initiation_adjusted` block: completed episodes split into `C_initiated_on_time`, `C_initiated_late`, and `C_initiation_not_assessed`, plus `on_time_initiation_and_completion_floor` (on-time initiation and completion by the deadline, divided by N_b). That floor is reported only when every completed episode has an assessable initiation window. A late disposition is reported as a pathway delay; it does not reset or erase the initiation assessment.

## FHIR R4 fixture

The synthetic FHIR fixture exercises selected native R4 elements and links:

- `Encounter.period.start` for eligibility date;
- `Observation.effectiveDateTime` and `Observation.valueString` for AI output;
- `ServiceRequest.authoredOn` for disposition date;
- `ServiceRequest.occurrencePeriod.end` (preferred) or `ServiceRequest.occurrenceDateTime` for the downstream deadline;
- `Task.basedOn` for linkage to the request;
- `Procedure.performedDateTime` or `Procedure.performedPeriod` for completed procedure timing;
- `Procedure.status = not-done` plus `statusReason` for affirmative procedure non-completion.

For multiple completed procedures linked to the same request, the earliest completion date is used. Any completed Procedure without a `performed[x]` date (or finished Encounter without a period) is rejected, even when another dated completion is linked to the same request. Evidence grade is never invented when it is absent.

A `not-done` Procedure dated before the earliest completion is treated as a rescheduled attempt: completion governs and a warning is issued. A `not-done` Procedure that is undated, or dated after the completion, is retained as contradictory evidence and fails the audit.

Audit-specific concepts such as branch vocabulary, evidence grade, source-of-record status, override state, and optional reference-resolution status remain extensions. The fixture tests serialization and extraction of the audit schema; it is not an implementation guide.

Extension URLs are configurable. In the FHIR `config.json`, `fhir_extension_base` sets the base URL (default `https://example.org/fhir/StructureDefinition/`), and `fhir_extension_urls` can override the URL of any individual concept (for example `{"episode-id": "https://site.example/ext/episode"}`). A bundle in which no eligibility Encounter is recognised fails the audit rather than passing with N0 = 0.

See `FHIR_MAPPING_NOTES.md` for details.

## Run

Valid CSV example:

```bash
python3 denominator_audit.py --input-dir examples/valid --threshold 0.50 --report output/valid_report.json
```

FHIR example:

```bash
python3 denominator_audit.py --fhir-bundle examples/fhir/synthea_augmented_ai_audit_bundle.json --config examples/fhir/config.json --extract-dir output/fhir_extract --threshold 0.50 --report output/fhir_report.json
```

Regression suite:

```bash
python3 -m unittest discover -s tests -v
```

The v0.5.2 suite contains **63 tests**. v0.5.2 adds the total-pathway view, the strategy-adjusted interval, the stress test and its closed-form check, the worked example, the truncating-event handling rule, same-day transition chains, explicit and inconsistent `transition_seq`, blank mandatory dates, trailing date content, ISO-8601/UTC normalisation, exact-integer tipping-point boundaries, hash-seed-independent report ordering, configurable and unrecognised FHIR extension bases, and the clustering summary. Earlier tests include the source-reconciliation and branch-transition cases from earlier versions plus R4 `Procedure.performed[x]`, `ServiceRequest.occurrencePeriod.end`, missing evidence grade, multiple completion resources, undated completion alongside a dated one, `Procedure.status=not-done` (including rescheduled and contradictory ordering), same-branch override rejection, the initiation identity, initiation-adjusted completion, missing initiation-window warnings, truncation/non-completion contradiction, and inappropriate evidence-grade probes.

## Statistical outputs

The utility reports the observed completion floor, U-based upper identification limit, Wilson interval for the observed completion proportion, Grade A/B-only floor, and tipping-point state. Wilson intervals are episode-level and assume independent episodes. Repeated patient IDs generate a warning, and every report includes a `clustering` block (number of patients, maximum episodes per patient, and `wilson_intervals_cluster_robust: false`). When patients contribute more than one episode the Wilson intervals understate uncertainty; cluster-aware inference (for example a patient-level cluster bootstrap) must be performed outside this QA utility.

Each episode has one index execution branch. Where a protocol requires several parallel next steps, each required step should be defined as its own accounting unit with its own denominator rather than combined into a composite episode state.

## Requirements

- Python 3.10 or later
- Standard library only
- No patient data are included

## License and version

MIT License. Version 0.5.2, 2026-09-25. See `CHANGELOG.md`.

## Outcome reasons and truncating-event handling

Every branch summary reports `F_by_reason`, `U_by_reason` and `T_by_reason`. F combines late completion (`completed_after_deadline`), documented refusal, documented no-show, cancellation and closed-source no-event (`validated_source_no_event`); these answer different operational questions and should be reported separately even when the binary timely-completion estimand is the primary result.

`truncating_event_handling` in `config.json` assigns each prespecified truncating event one ICH E9(R1)-style strategy: `composite` (counted as not completing the target event), `while_eligible` (removed from that estimand's denominator and reported), or `competing_event` (analysed as a competing event). When the key is present, every truncating event must have a valid strategy, and every summary includes `strategy_adjusted`: the identification interval and tipping point after applying the strategies. Composite keeps T in the denominator, giving [C/N, (C+U)/N]; while-eligible removes those T, giving [C/(N-T), (C+U)/(N-T)]; competing-event gives the composite interval for the fixed-horizon quantity only: with every episode followed to the prespecified deadline, the cumulative incidence of completion at the deadline equals C/N. Cause-specific hazards, subdistribution hazards and cumulative incidence curves over time are different estimands with different estimators, outside this utility. An event after which the target care can still occur and be observed, such as transfer to another provider, is not a truncating event: the episode is classified by whether the target event occurred. The example configurations use `composite` for death and `while_eligible` for clinical contraindication as prespecified choices for these synthetic examples; in a real protocol each strategy must be justified by the clinical question.

## Worked example

`examples/worked_example` is a synthetic hybrid deployment of 100 eligible episodes, used in the manuscript to contrast a conventional cascade with denominator-preserving accounting:

```
python3 denominator_audit.py --input-dir examples/worked_example --threshold 0.50 --report output/worked_example_report.json
```

## Total-pathway (indicated-population) view

`total_pathway.csv` (optional) supports the primary comparative estimand, which the manuscript calls the indicated-population estimand: timely completion of the target care among eligible episodes for which it is indicated. `config.json` then needs `total_pathway_indication` (`universal`, or `reference_standard` applied to every episode independently of AI output and arm) and `total_pathway_window_days` (the deadline, counted from the eligibility date). Each eligible episode has exactly one row with `indicated` = 1 or 0. Not-indicated episodes are counted and excluded, so they are neither completions nor failures. Each indicated episode is classified C, F, U or T for the target event with the same rules as branch outcomes. Upstream pathway states (not attempted, technical failure, disposition branch, override) are never endpoint states: they are reported in `by_pathway_state`, a cross-tabulation of pathway state by endpoint, and the identity `N0 = N_indicated + N_not_indicated; N_indicated = C + F + U + T` is checked.

`examples/total_pathway_example` is the eight-episode row-level example in the manuscript:

```
python3 denominator_audit.py --input-dir examples/total_pathway_example --threshold 0.50 --report output/total_pathway_example_report.json
```

## Stress test for the worked counterexample

`tools/scenario_grid.py` is a deterministic, pedagogic stress test, not a simulation of deployments. It compares a conventional analysis (completion among referrals with an ascertained outcome) with pathway accounting (floor, upper bound and tipping point) across 50 mixtures of completion among ascertained referrals (40%-80%), unascertained share (0%-40%) and truncating share (0% or 5%), for 200 index referrals and a 50% threshold:

```
python3 tools/scenario_grid.py --report output/scenario_grid.json
```

The grid values are author-specified. With T handled as composite, write p = C/(C+F), s_U = U/N and s_T = T/N. Then the floor is p(1 - s_U - s_T) and the upper bound is p(1 - s_T) + s_U(1 - p), so a complete-case conclusion that q is met is established only when s_U + s_T <= 1 - q/p, and the interval shows q is not met when s_U(1 - p) < q - p(1 - s_T). `closed_form_call()` applies these conditions, and the regression suite checks that they reproduce every grid cell. The two analyses reach the same conclusion in 23 of the 50 grid cells. In 26 of the other 27 the conventional analysis gives a definite answer where accounting gives "not established"; in one, truncating events under the composite strategy reverse it. Technical failures, non-attempts and overrides are upstream of the referral branch and change neither branch figure, so they are not varied; they would change a total-pathway estimand. The grid shows where the analyses diverge; it says nothing about how often these mixtures occur in practice.

## Coverage and continuous integration

`.github/workflows/tests.yml` runs the suite on Linux, Windows and macOS under Python 3.10, 3.11 and 3.12, and reports coverage. Locally, with `coverage>=7.10` installed (the utility itself remains standard-library only):

```
python -m coverage run -m unittest discover -s tests
python -m coverage combine
python -m coverage report
```

`.coveragerc` measures code executed in the subprocesses the tests launch. Combined statement and branch coverage of `denominator_audit.py` is 84%, and 84% including `tools/scenario_grid.py` (`output/coverage_report.txt`).
