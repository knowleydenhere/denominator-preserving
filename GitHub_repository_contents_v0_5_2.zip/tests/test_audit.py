import json
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "denominator_audit.py"


class TestAudit(unittest.TestCase):
    def run_case(self, name, expected_message=None, expect_ok=False, threshold=None):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "report.json"
            cmd = [sys.executable, str(SCRIPT), "--input-dir", str(ROOT / "examples" / "adversarial" / name), "--report", str(report)]
            if threshold is not None:
                cmd += ["--threshold", str(threshold)]
            p = subprocess.run(cmd, capture_output=True, text=True)
            with open(report, encoding="utf-8") as fh:
                data = json.load(fh)
            if expect_ok:
                self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            else:
                self.assertNotEqual(p.returncode, 0, name)
                self.assertTrue(data.get("errors"), name)
                if expected_message:
                    self.assertTrue(
                        any(expected_message in e for e in data["errors"]),
                        f"{name}: expected error containing {expected_message!r}; got {data['errors']}",
                    )
            return data

    def run_valid(self, subdir="valid", threshold=0.5):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            p = subprocess.run(
                [sys.executable, str(SCRIPT), "--input-dir", str(ROOT / "examples" / subdir), "--threshold", str(threshold), "--report", str(report)],
                capture_output=True,
                text=True,
            )
            with open(report, encoding="utf-8") as fh:
                data = json.load(fh)
            self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            return data


    def run_fhir_case(self, name, expect_ok=True, expected_message=None):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            extract = Path(td) / "extract"
            p = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--fhir-bundle",
                    str(ROOT / "examples" / "fhir" / "adversarial" / f"{name}.json"),
                    "--config",
                    str(ROOT / "examples" / "fhir" / "config.json"),
                    "--report",
                    str(report),
                    "--extract-dir",
                    str(extract),
                ],
                capture_output=True,
                text=True,
            )
            with open(report, encoding="utf-8") as fh:
                d = json.load(fh)
            if expect_ok:
                self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            else:
                self.assertNotEqual(p.returncode, 0, name)
                if expected_message:
                    self.assertTrue(any(expected_message in e for e in d.get("errors", [])), f"{name}: {d.get('errors')}")
            return d

    def test_valid(self):
        d = self.run_valid()
        self.assertEqual(d["N_disposition_unascertained"], 1)
        self.assertEqual(d["N_disposition_extract_missing"], 0)

    def test_missing_ai(self):
        self.run_case("missing_ai_row", "missing ai_log row")

    def test_invalid_boolean_specific(self):
        self.run_case("invalid_boolean", "ai_attempted must be 0, 1, or unknown")

    def test_contradictory_attempt_record(self):
        self.run_case("contradictory_record", "AI not attempted but technical/output data are present")

    def test_duplicate(self):
        self.run_case("duplicate_episode", "duplicate episode_id")

    def test_branch_typo(self):
        self.run_case("invalid_branch", "invalid branch 'action_requried'")

    def test_invalid_t(self):
        self.run_case("invalid_t_reason", "is not in the prespecified truncating-event list")

    def test_missing_grade(self):
        self.run_case("missing_evidence_grade", "requires evidence_grade A/B/C")

    def test_dropped_required_outcome(self):
        self.run_case("dropped_required_outcome", "requires exactly one outcome row; found 0")

    def test_required_marked_no_step(self):
        self.run_case("required_branch_marked_no_step", "conflicts with configured branch rule")

    def test_outcome_without_execution_branch(self):
        self.run_case("outcome_without_execution_branch", "neither the index branch nor a recorded derived transition")

    def test_missing_column(self):
        self.run_case("missing_column", "missing required columns: technical_failure")

    def test_missing_disposition_extract_is_not_clinical_unascertainment(self):
        self.run_case("missing_disposition_extract", "missing disposition extract row; missing record is not equivalent to disposition unascertained")

    def test_derived_branch_is_reported_separately(self):
        d = self.run_case("derived_branch_separate", expect_ok=True, threshold=0.5)
        idx = {x["branch"]: x for x in d["index_branch_summaries"]}
        drv = {x["branch"]: x for x in d["derived_branch_summaries"]}
        self.assertEqual(idx["action_required"]["N"], 2)
        self.assertEqual(drv["action_required"]["N"], 1)

    def test_derived_branch_requires_own_outcome(self):
        self.run_case("derived_branch_missing_outcome", "derived branch 'action_required' requires exactly one outcome row; found 0")

    def test_late_completion_is_F_not_U(self):
        d = self.run_case("late_completion", expect_ok=True, threshold=0.5)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "E003" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "F")
        self.assertEqual(e["derived_reason"], "completed_after_deadline")

    def test_completion_noncompletion_contradiction(self):
        self.run_case("completion_noncompletion_contradiction", "contradictory evidence: completion_date and affirmative_noncompletion=1")

    def test_completion_before_branch(self):
        self.run_case("completion_before_branch", "completion_date precedes branch entry")

    def test_deadline_must_match_configured_window(self):
        self.run_case("deadline_mismatch", "does not match configured deadline")

    def test_invalid_eligibility_date(self):
        self.run_case("invalid_eligibility_date", "invalid eligibility_date date")

    def test_blank_transition_episode(self):
        self.run_case("blank_transition_episode", "transitions: blank episode_id")

    def test_wrong_transition_source_branch(self):
        self.run_case("wrong_transition_from_branch", "does not match the episode's actual index/previous derived branch")

    def test_reference_status_rejected_on_execution_row(self):
        self.run_case("reference_status_on_execution", "reference_status belongs to ai_output accountability rows")

    def test_tipping_bounds(self):
        sys.path.insert(0, str(ROOT))
        import denominator_audit as da
        self.assertEqual(da.tipping(3, 1, 4, 0.2)["status"], "already_met")
        self.assertEqual(da.tipping(0, 1, 4, 0.9)["status"], "unreachable")
        self.assertIsNone(da.tipping(0, 1, 4, 0.9)["fraction_U"])

    def test_source_of_record_rule(self):
        sys.path.insert(0, str(ROOT))
        import denominator_audit as da
        cfg = {"truncating_events": ["death_before_deadline"]}
        base = {
            "episode_id": "X",
            "deadline": "2026-02-01",
            "completion_date": "",
            "evidence_grade": "",
            "affirmative_noncompletion": "0",
            "noncompletion_reason": "",
            "t_reason": "",
            "t_event_date": "",
        }
        errs = []
        r = dict(base, source_of_record="validated_closed", observable_through_deadline="1")
        state, _, _ = da.derive_outcome(r, cfg, errs, date(2026, 1, 1), date(2026, 2, 1))
        self.assertEqual(state, "F")
        self.assertFalse(errs)
        errs = []
        r = dict(base, source_of_record="open", observable_through_deadline="1")
        state, reason, _ = da.derive_outcome(r, cfg, errs, date(2026, 1, 1), date(2026, 2, 1))
        self.assertEqual(state, "U")
        self.assertEqual(reason, "open_or_incomplete_source")

    def test_autonomous_safety_override_changes_execution_branch(self):
        d = self.run_valid("autonomous_override")
        self.assertEqual(d["execution_index_branches"], {"no_immediate_action": 1})

    def test_fhir_fixture(self):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            extract = Path(td) / "extract"
            p = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--fhir-bundle",
                    str(ROOT / "examples" / "fhir" / "synthea_augmented_ai_audit_bundle.json"),
                    "--config",
                    str(ROOT / "examples" / "fhir" / "config.json"),
                    "--report",
                    str(report),
                    "--extract-dir",
                    str(extract),
                ],
                capture_output=True,
                text=True,
            )
            self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            with open(report, encoding="utf-8") as fh:
                d = json.load(fh)
            self.assertEqual(d["N0"], 3)
            self.assertEqual(d["N_technical_failure"], 1)
            e = next(x for x in d["episode_states"] if x["episode_id"] == "F001")
            self.assertEqual(e["derived_state"], "C")
            self.assertEqual(e["completion_date"], "2026-04-10")

    def test_autonomous_same_branch_override_rejected(self):
        d = self.run_case("autonomous_same_branch_override", "autonomous safety override must change the execution branch")
        # Single-cause fixture: the same-branch override is the only fault.
        self.assertEqual(d["errors"], ["A001: autonomous safety override must change the execution branch"])

    def test_disposition_delay_reported_against_initiation_window(self):
        d = self.run_case("disposition_delay", expect_ok=True, threshold=0.5)
        self.assertEqual(d["N_disposition_late"], 1)
        a = next(x for x in d["accountability"] if x["episode_id"] == "E003")
        self.assertEqual(a["disposition_lag_days"], 30)
        self.assertEqual(a["disposition_window_days"], 14)
        self.assertFalse(a["disposition_within_window"])
        self.assertTrue(any("beyond the prespecified 14-day initiation window" in w for w in d["warnings"]))

    def test_t_and_affirmative_noncompletion_contradiction(self):
        self.run_case("t_noncompletion_contradiction", "affirmative_noncompletion=1 and truncating-event evidence are both present")

    def test_grade_without_completion_rejected(self):
        self.run_case("grade_on_noncompletion", "evidence_grade is only valid when completion evidence is present")

    def test_fhir_r4_performed_datetime_completion(self):
        d = self.run_fhir_case("r4_performed_datetime", expect_ok=True)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "C")
        self.assertEqual(e["completion_date"], "2026-04-10")

    def test_fhir_missing_procedure_grade_rejected(self):
        self.run_fhir_case("missing_procedure_grade", expect_ok=False, expected_message="requires evidence_grade A/B/C")

    def test_fhir_multiple_completed_procedures_use_earliest(self):
        d = self.run_fhir_case("two_procedures_earliest_wins", expect_ok=True)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "C")
        self.assertEqual(e["completion_date"], "2026-04-10")

    def test_fhir_not_done_is_affirmative_noncompletion(self):
        d = self.run_fhir_case("procedure_not_done", expect_ok=True)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "F")
        self.assertEqual(e["derived_reason"], "patient declined procedure")

    def test_fhir_completed_procedure_without_performed_date_fails(self):
        self.run_fhir_case("completed_procedure_missing_date", expect_ok=False, expected_message="has no performed[x] date")

    def test_initiation_identity_reported(self):
        d = self.run_case("disposition_delay", expect_ok=True, threshold=0.5)
        ini = d["initiation"]
        self.assertEqual(sum(ini["totals"].values()), d["N_AI_output"])
        self.assertEqual(ini["totals"]["late"], 1)
        self.assertEqual(ini["totals"]["disposition_unascertained"], d["N_disposition_unascertained"])

    def test_initiation_adjusted_completion(self):
        d = self.run_case("disposition_delay", expect_ok=True, threshold=0.5)
        act = next(x for x in d["index_branch_summaries"] if x["branch"] == "action_required")
        adj = act["initiation_adjusted"]
        self.assertEqual(adj["C_initiated_on_time"] + adj["C_initiated_late"] + adj["C_initiation_not_assessed"], act["C"])
        self.assertEqual(adj["C_initiated_late"], 1)
        self.assertLess(adj["on_time_initiation_and_completion_floor"], act["floor"])

    def test_missing_initiation_window_warns(self):
        d = self.run_case("no_initiation_window", expect_ok=True, threshold=0.5)
        self.assertTrue(any("No disposition_windows_days configured" in w for w in d["warnings"]))
        self.assertEqual(d["initiation"]["totals"]["late"], 0)
        self.assertGreater(d["initiation"]["totals"]["no_window_configured"], 0)

    def test_fhir_occurrence_period_end_is_deadline(self):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            p = subprocess.run([sys.executable, str(SCRIPT), "--fhir-bundle", str(ROOT / "examples" / "fhir" / "synthea_augmented_ai_audit_bundle.json"),
                                "--config", str(ROOT / "examples" / "fhir" / "config.json"), "--report", str(report), "--extract-dir", str(Path(td) / "x")],
                               capture_output=True, text=True)
            self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
            d = json.load(open(report, encoding="utf-8"))
            e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
            self.assertEqual(e["resolved_deadline"], "2026-04-26")

    def test_fhir_undated_completion_flagged_even_with_dated_one(self):
        self.run_fhir_case("undated_second_completion", expect_ok=False, expected_message="has no performed[x] date")

    def test_fhir_not_done_before_completion_is_reschedule(self):
        d = self.run_fhir_case("rescheduled_after_not_done", expect_ok=True)
        e = next(x for x in d["episode_states"] if x["episode_id"] == "F001" and x["view"] == "execution")
        self.assertEqual(e["derived_state"], "C")
        self.assertTrue(any("treated as a rescheduled attempt" in w for w in d["warnings"]))

    def test_fhir_not_done_after_completion_is_contradiction(self):
        self.run_fhir_case("not_done_after_completion", expect_ok=False, expected_message="contradictory evidence: completion_date and affirmative_noncompletion=1")


    # ---- v0.5.2 additions -------------------------------------------------

    def test_same_day_transition_chain_resolved_without_name_order(self):
        d = self.run_case("same_day_transition_chain", expect_ok=True, threshold=0.5)
        drv = {x["branch"]: x for x in d["derived_branch_summaries"]}
        self.assertEqual(drv["action_required"]["N"], 1)
        self.assertTrue(any("order resolved from the branch chain" in w for w in d["warnings"]))

    def test_transition_seq_explicit_order(self):
        d = self.run_case("transition_seq_explicit", expect_ok=True, threshold=0.5)
        self.assertFalse(any("share transition_date" in w for w in d["warnings"]))

    def test_transition_seq_contradicting_dates_rejected(self):
        self.run_case("transition_seq_date_conflict", "transition_seq order contradicts transition_date")

    def test_partial_transition_seq_rejected(self):
        self.run_case("transition_seq_partial", "transition_seq must be supplied for all or none")

    def test_blank_eligibility_date_rejected(self):
        self.run_case("blank_eligibility_date", "eligibility_date is required but blank")

    def test_blank_transition_date_rejected(self):
        self.run_case("blank_transition_date", "transition_date is required but blank")

    def test_trailing_date_content_rejected(self):
        self.run_case("trailing_date_garbage", "invalid eligibility_date date '2026-01-01xyz'")

    def test_iso_date_parsing_and_utc_normalisation(self):
        sys.path.insert(0, str(ROOT))
        import denominator_audit as da
        self.assertEqual(da.iso_to_date("2026-01-02"), date(2026, 1, 2))
        self.assertEqual(da.iso_to_date("2026-01-02T10:00:00Z"), date(2026, 1, 2))
        self.assertEqual(da.iso_to_date("2026-01-02T23:30:00-05:00"), date(2026, 1, 3))
        self.assertEqual(da.iso_to_date("2026-01-02T23:30:00"), date(2026, 1, 2))
        for bad in ["2026-01-02xyz", "2026-13-01", "02/01/2026", "2026-01-02 garbage"]:
            with self.assertRaises(ValueError):
                da.iso_to_date(bad)

    def test_tipping_exact_integer_boundaries(self):
        sys.path.insert(0, str(ROOT))
        import denominator_audit as da
        # q*n is an exact integer in real arithmetic but not in binary floating point.
        self.assertEqual(da.tipping(3, 5, 10, 0.3)["status"], "already_met")
        self.assertEqual(da.tipping(7, 3, 10, 0.7)["status"], "already_met")
        self.assertEqual(da.tipping(2, 5, 10, 0.3)["needed_from_U"], 1)
        self.assertEqual(da.tipping(0, 10, 10, 0.7)["needed_from_U"], 7)
        self.assertEqual(da.tipping(0, 5, 10, 0.1)["needed_from_U"], 1)
        self.assertEqual(da.tipping(0, 3, 10, 0.3)["fraction_U"], 1.0)
        self.assertEqual(da.tipping(0, 2, 10, 0.3)["status"], "unreachable")

    def test_report_order_independent_of_hash_seed(self):
        outs = []
        for seed in ["1", "2", "3"]:
            with tempfile.TemporaryDirectory() as td:
                report = Path(td) / "r.json"
                env = dict(os.environ, PYTHONHASHSEED=seed)
                subprocess.run([sys.executable, str(SCRIPT), "--input-dir", str(ROOT / "examples" / "adversarial" / "missing_two_ai_rows"),
                                "--report", str(report)], capture_output=True, text=True, env=env)
                outs.append(report.read_text(encoding="utf-8"))
        self.assertEqual(outs[0], outs[1])
        self.assertEqual(outs[1], outs[2])
        self.assertIn("E009: missing ai_log row", outs[0])

    def _run_fhir(self, bundle, config):
        with tempfile.TemporaryDirectory() as td:
            report = Path(td) / "r.json"
            p = subprocess.run([sys.executable, str(SCRIPT), "--fhir-bundle", str(bundle), "--config", str(config),
                                "--report", str(report), "--extract-dir", str(Path(td) / "x")], capture_output=True, text=True)
            with open(report, encoding="utf-8") as fh:
                return p.returncode, json.load(fh)

    def test_fhir_configurable_extension_base(self):
        code, d = self._run_fhir(ROOT / "examples" / "fhir" / "adversarial" / "custom_extension_base.json",
                                 ROOT / "examples" / "fhir" / "config_custom_extension_base.json")
        self.assertEqual(code, 0, d.get("errors"))
        self.assertEqual(d["N0"], 3)

    def test_fhir_unrecognised_extension_base_is_an_error(self):
        code, d = self._run_fhir(ROOT / "examples" / "fhir" / "adversarial" / "custom_extension_base.json",
                                 ROOT / "examples" / "fhir" / "config.json")
        self.assertNotEqual(code, 0)
        self.assertTrue(any("no eligibility Encounters were recognised" in e for e in d["errors"]), d["errors"])

    def test_clustering_summary_reported(self):
        code, d = self._run_fhir(ROOT / "examples" / "fhir" / "synthea_augmented_ai_audit_bundle.json",
                                 ROOT / "examples" / "fhir" / "config.json")
        self.assertEqual(code, 0)
        cl = d["clustering"]
        self.assertEqual((cl["N_patients"], cl["max_episodes_per_patient"]), (1, 3))
        self.assertFalse(cl["wilson_intervals_cluster_robust"])


    def test_worked_example_reproduces_manuscript_table(self):
        d = self.run_valid("worked_example", threshold=0.5)
        self.assertEqual((d["N0"], d["N_not_attempted"], d["N_technical_failure"], d["N_AI_output"]), (100, 5, 15, 80))
        self.assertEqual(sum(1 for a in d["accountability"] if a["overridden"]), 8)
        act = next(x for x in d["index_branch_summaries"] if x["branch"] == "action_required")
        self.assertEqual((act["N"], act["C"], act["F"], act["U"], act["T"]), (32, 14, 6, 10, 2))
        self.assertAlmostEqual(act["floor"], 0.4375)
        self.assertAlmostEqual(act["upper"], 0.75)
        self.assertEqual(act["tipping"]["needed_from_U"], 2)
        self.assertEqual(act["F_by_reason"], {"completed_after_deadline": 2, "documented_no_show": 2, "documented_refusal": 2})
        self.assertEqual(act["T_by_reason"], {"death_before_deadline": 2})
        drv = next(x for x in d["derived_branch_summaries"] if x["branch"] == "action_required")
        self.assertEqual((drv["N"], drv["C"], drv["U"]), (4, 2, 2))
        # A conventional cascade pools index and derived referrals and drops U and T: 16/22.
        known = act["C"] + act["F"] + drv["C"] + drv["F"]
        self.assertEqual((act["C"] + drv["C"], known), (16, 22))

    def test_truncating_event_handling_must_cover_every_event(self):
        self.run_case("truncating_handling_incomplete", "truncating_event_handling has no strategy for clinical_contraindication")


    def test_alternative_mixture_grid(self):
        sys.path.insert(0, str(ROOT / "tools"))
        import scenario_grid as sg
        rows = sg.grid()
        self.assertEqual(len(rows), 50)
        self.assertEqual(sum(r["agree"] for r in rows), 23)
        reversals = [r for r in rows if {r["conventional_call"], r["accounting_call"]} == {"met", "not met"}]
        self.assertEqual([(r["T"], r["U"], r["p_ascertained"]) for r in reversals], [(10, 0, 0.5)])
        # Every scenario keeps N = C + F + U + T and the conventional figure equals completion among ascertained.
        for r in rows:
            self.assertEqual(r["C"] + r["F"] + r["U"] + r["T"], r["N"])
            self.assertAlmostEqual(r["conventional"], r["p_ascertained"])


    def test_grid_matches_closed_form_condition(self):
        sys.path.insert(0, str(ROOT / "tools"))
        import scenario_grid as sg
        for r in sg.grid():
            self.assertEqual(sg.closed_form_call(r["C"], r["F"], r["U"], r["T"], 0.5), r["accounting_call"], r)
        # Worked counterexample index branch: p = 14/20 = 0.70, margin 1 - 0.5/0.70 = 0.286 < (10 + 2)/32 = 0.375.
        self.assertEqual(sg.closed_form_call(14, 6, 10, 2, 0.5), "not established")
        self.assertEqual(sg.closed_form_call(14, 6, 5, 0, 0.5), "met")

    def test_interval_after_truncation_strategy(self):
        sys.path.insert(0, str(ROOT))
        import denominator_audit as da
        rows = ([{"derived_state": "C", "derived_reason": ""}] * 5
                + [{"derived_state": "F", "derived_reason": "documented_refusal"}] * 2
                + [{"derived_state": "U", "derived_reason": "open_or_incomplete_source"}] * 2
                + [{"derived_state": "T", "derived_reason": "death_before_deadline"}]
                + [{"derived_state": "T", "derived_reason": "clinical_contraindication"}] * 2)
        h = {"death_before_deadline": "composite", "clinical_contraindication": "while_eligible"}
        s = da.summarize_rows(rows, 0.5, [], "x", h)
        self.assertEqual(s["N"], 12)
        self.assertAlmostEqual(s["floor"], 5 / 12)
        adj = s["strategy_adjusted"]
        self.assertEqual((adj["denominator"], adj["T_composite"], adj["T_while_eligible"]), (10, 1, 2))
        self.assertAlmostEqual(adj["floor"], 0.5)
        self.assertAlmostEqual(adj["upper"], 0.7)
        self.assertEqual(adj["tipping"]["status"], "already_met")
        # Competing event with follow-up to the deadline: cumulative incidence at the deadline equals C/N.
        ce = da.summarize_rows(rows, 0.5, [], "x", {k: "competing_event" for k in h})["strategy_adjusted"]
        self.assertEqual(ce["denominator"], 12)
        self.assertAlmostEqual(ce["floor"], 5 / 12)
        self.assertIn("Aalen-Johansen", ce["note"])
        self.assertIsNone(da.summarize_rows(rows, 0.5, [], "x")["strategy_adjusted"])

    def test_total_pathway_row_level_example(self):
        d = self.run_valid("total_pathway_example", threshold=0.5)
        tp = d["total_pathway"]
        self.assertEqual((tp["N_indicated"], tp["N_not_indicated"]), (7, 1))
        self.assertEqual((tp["C"], tp["F"], tp["U"], tp["T"]), (2, 3, 1, 1))
        self.assertAlmostEqual(tp["floor"], 2 / 7)
        self.assertAlmostEqual(tp["upper"], 3 / 7)
        self.assertEqual(tp["tipping"]["status"], "unreachable")
        states = {r["episode_id"]: (r["pathway_state"], r["derived_state"]) for r in tp["episode_states"]}
        self.assertEqual(states, {
            "P01": ("action_required", "C"),
            "P02": ("not_attempted", "F"),
            "P03": ("technical_failure", "C"),
            "P04": ("no_immediate_action", "F"),
            "P05": ("action_required", "U"),
            "P06": ("action_required", "T"),
            "P08": ("no_immediate_action_after_override", "F"),
        })
        # The referral branch alone sees 3 of the 8 episodes.
        act = next(x for x in d["index_branch_summaries"] if x["branch"] == "action_required")
        self.assertEqual((act["N"], act["C"], act["F"], act["U"], act["T"]), (3, 1, 0, 1, 1))

    def test_total_pathway_requires_every_episode(self):
        self.run_case("total_pathway_missing_row", "P04: missing total_pathway row")


if __name__ == "__main__":
    unittest.main()
