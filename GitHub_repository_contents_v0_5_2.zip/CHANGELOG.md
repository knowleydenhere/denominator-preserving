# Changelog

## 0.5.2 (2026-09-25)

Software-QA hardening in response to external code review. No accounting rule, identity, or C/F/U/T definition changed; the valid CSV reference report is identical to v0.5.1 apart from the version string and the new `clustering` block.

Fixed
- Same-day transitions were ordered alphabetically by derived branch, which could reject a valid chain (for example `indeterminate_output -> no_immediate_action -> action_required` on one day). Ordering now uses an optional `transition_seq` column or, without it, date plus branch-chain resolution. A warning recommends `transition_seq` when transitions share a date.
- A blank `eligibility_date`, or a blank `transition_date` into a branch without a required next step, previously passed silently. Both are now mandatory.
- Dates were truncated to their first 10 characters, so `2026-01-01xyz` was accepted and offset-bearing date-times were not normalised. Dates must now be complete ISO-8601 values; offset-bearing date-times are converted to UTC.
- Error messages could appear in a different order between runs (set iteration under hash randomisation). Iteration is now sorted and reports are byte-reproducible.
- A FHIR bundle whose extensions used an unexpected base URL produced N0 = 0 and passed. It now fails with an explicit message.

Added
- `transition_seq` (CSV) and `transition-seq` extension (FHIR).
- `fhir_extension_base` and `fhir_extension_urls` configuration keys.
- `clustering` block in the report.
- The already-met tipping-point test uses the same floating-point guard as the required-conversion count.
- `F_by_reason`, `U_by_reason` and `T_by_reason` in every branch summary.
- Optional `truncating_event_handling` configuration (composite, while_eligible or competing_event per truncating event), validated when present and used in the example configurations.
- `examples/worked_example`: 100-episode synthetic deployment reproducing the manuscript's conventional-versus-denominator-preserving comparison.
- Coverage configuration (`.coveragerc`, 84% combined statement and branch coverage) and a cross-platform CI workflow.
- `tools/scenario_grid.py`: deterministic stress test for the worked counterexample (50 author-specified grid cells).
- Optional total-pathway view (`total_pathway.csv`, `total_pathway_indication`, `total_pathway_window_days`): indication fixed before analysis for every eligible episode, C/F/U/T for the target event among indicated episodes, and a pathway-state by endpoint cross-tabulation; `examples/total_pathway_example` reproduces the manuscript's row-level example.
- `strategy_adjusted` in every summary: identification interval and tipping point after applying each truncating reason's prespecified strategy.
- `closed_form_call()` in `tools/scenario_grid.py`: the margin conditions under which complete-case reporting and the identification interval agree.
- Competing-event note and documentation state that the interval answers only the fixed-horizon quantity at the prespecified deadline.
- 20 regression tests (63 in total).
- Test 28 fixture (`autonomous_same_branch_override`) now includes the outcome row it previously lacked, so the same-branch override is its only fault; the test asserts that exactly one error is raised.
